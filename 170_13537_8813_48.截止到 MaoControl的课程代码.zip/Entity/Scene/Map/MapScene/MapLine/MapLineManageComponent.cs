using Fantasy.Entitas;

namespace Fantasy;

/// <summary>
/// Map 服务器本地的分线管理组件，挂载到 MapScene 上，每个 MapScene 对应一个实例。
/// 负责维护本服务器上所有 SubScene 分线的实例引用，以及从中控同步过来的分线状态信息。
/// </summary>
public sealed class MapLineManageComponent : Entity
{
    /// <summary>
    /// 当前 MapScene 下所有分线的 SubScene 实例。Key 为 SubScene 的 Id。
    /// </summary>
    public readonly Dictionary<long, SubScene> Lines = new Dictionary<long, SubScene>();
}