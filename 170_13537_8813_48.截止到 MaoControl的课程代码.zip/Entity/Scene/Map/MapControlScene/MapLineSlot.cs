using Fantasy.Entitas;
using Fantasy.Platform.Net;

namespace Fantasy;

/// <summary>
/// 中控侧单条分线的运行时数据实体。由<see cref="MapLineSlotManagerComponent"/> 持有。
/// 记录分线的地址、线号、玩家人数及生命周期，是中控进行负载均衡和分线调度的核心数据载体。
/// </summary>
public sealed class MapLineSlot : Entity
{
    /// <summary>
    /// 分线对应的子场景 Map（SubScene）地址。玩家实际连接的目标地址
    /// </summary>
    public long MapLineSubSceneAddress;
    
    /// <summary>
    /// 分线所属的顶级 MapScene 的地址
    /// </summary>
    public long MapSceneAddress;
    
    /// <summary>
    /// 分线创建时间(毫秒)
    /// </summary>
    public long CreateTime;
    
    /// <summary>
    /// 分线过期时间，到期后可被回收
    /// </summary>
    public long ExpireTime;
    
    /// <summary>
    /// 分线展示线号(如1、2、3)
    /// </summary>
    public int LineNumber;

    /// <summary>
    /// 所属的 SceneConfigId
    /// </summary>
    public uint SceneConfigId;

    /// <summary>
    /// 获取所属的 SceneConfig
    /// </summary>
    public SceneConfig SceneConfig => SceneConfigData.Instance.Get(SceneConfigId);

    /// <summary>
    /// 当前分线的玩家人数(场景人数+请求人数)
    /// </summary>
    public int UnitCount => Units.Count + Request.Count;

    /// <summary>
    /// 定时器 Id，用于周期性清理<see cref="Request"/> 中过期的条目
    /// </summary>
    public long TimerId;

    /// <summary>
    /// 关键的MapLineSlotManagerComponent
    /// </summary>
    public MapLineSlotManagerComponent MapLineSlotManagerComponent;

    /// <summary>
    /// 已经确认加到该分线的玩家 UnitId 集合。
    /// </summary>
    public readonly HashSet<long> Units = new HashSet<long>();

    /// <summary>
    /// 正在请求进入该分线的玩家，key 为 unitId，Value 为请求过期的时间（毫秒）
    /// </summary>
    public readonly Dictionary<long, long> Request = new Dictionary<long, long>();
}