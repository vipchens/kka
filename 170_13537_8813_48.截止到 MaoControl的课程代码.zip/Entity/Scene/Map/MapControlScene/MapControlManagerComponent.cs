using Fantasy.DataStructure.Collection;
using Fantasy.Entitas;
using Fantasy.Platform.Net;

namespace Fantasy;

/// <summary>
/// 全局地图管理组件
/// 管理所有 map 服务器节点，负责 map 服服务器的负载均衡与分线管理组件的生命周期。
/// </summary>
public sealed class MapControlManagerComponent : Entity
{
    /// <summary>
    /// 当前所有地图 Scene 的数据，按玩家人数升序排序，用于快速选出负载最低的 map 服务器。
    /// </summary>
    public readonly PriorityQueue<SceneConfig, int> MapScenes = new PriorityQueue<SceneConfig, int>();

    /// <summary>
    /// 按照SceneConfig也就是 Scene来进行分组
    /// </summary>
    public readonly OneToManyList<uint, MapLineSlot> MapLineSlotBySceneConfig = new OneToManyList<uint, MapLineSlot>();

    /// <summary>
    /// 各地图的分线管理组件，key 为地图配置表 Id（MapConfigId）
    /// </summary>
    public readonly Dictionary<int, MapLineSlotManagerComponent> MapLineSlots = new Dictionary<int, MapLineSlotManagerComponent>();
}

