using Fantasy.Entitas;
using Fantasy.Table;
#pragma warning disable CS8767 // Nullability of reference types in type of parameter doesn't match implicitly implemented member (possibly because of nullability attributes).

namespace Fantasy;

/// <summary>
/// 单个地图的分线管理组件。每个地图配置都对应一个实例。
/// 负责该地图的所有分线创建、合并、线号分配及负责追踪。
/// </summary>
public sealed class MapLineSlotManagerComponent : Entity
{
    /// <summary>
    /// 对应的地图配置表 Id
    /// </summary>
    public int MapConfigId;
    
    /// <summary>
    /// 下一个待分配的线号，递增。
    /// </summary>
    public int NextLineNumber;
    
    /// <summary>
    /// 获取该地图的配置信息。
    /// </summary>
    public MapConfig Config => Fantasy.Config.MapTable.Get(MapConfigId);
    
    /// <summary>
    ///  当前所有分线，key为MapLineSlot.Id，用于 Id快速查询分线。
    /// </summary>
    public readonly Dictionary<long, MapLineSlot> MapLineSlots = new Dictionary<long, MapLineSlot>();

    /// <summary>
    /// 分线的有序集合、按照玩家人数升序排列，用于快读定位负载的最低分线。
    /// </summary>
    public readonly SortedSet<MapLineSlot> MapLineSlotSorted = new SortedSet<MapLineSlot>(MapLineSlotComparer.Instance);

    /// <summary>
    /// 已回收的线号池，合线后控制的线号存入此处，下次创建分线时优先从这里取最小值复用。
    /// </summary>
    public readonly PriorityQueue<int, int> RecycledLineNumbers = new PriorityQueue<int, int>();
}

/// <summary>
/// <see cref="MapLineSlot"/>的排序比较器。
/// 排序规则:先按玩家人数升序，人数相同按 Id 升序。
/// </summary>
internal sealed class MapLineSlotComparer : IComparer<MapLineSlot>
{
    public static readonly  MapLineSlotComparer Instance = new MapLineSlotComparer();
    
    private MapLineSlotComparer() { }
    
    public int Compare(MapLineSlot x, MapLineSlot y)
    {
        // 先按人数升序，人数最小的排在最前面
        var cmp = x.UnitCount.CompareTo(y.UnitCount);

        if (cmp != 0)
        {
            return cmp;
        }
        
        // 人数相同的时候用 ID做到比较，保证不同元素下不会被视为相同
        return x.Id.CompareTo(y.Id);
    }
}