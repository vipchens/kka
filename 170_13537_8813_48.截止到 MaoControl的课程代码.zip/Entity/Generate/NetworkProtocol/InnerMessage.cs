using LightProto;
using MemoryPack;
using System;
using System.Collections.Generic;
using MongoDB.Bson.Serialization.Attributes;
using Fantasy;
using Fantasy.Pool;
using Fantasy.Network.Interface;
using Fantasy.Serialize;

// ReSharper disable InconsistentNaming
// ReSharper disable CollectionNeverUpdated.Global
// ReSharper disable RedundantTypeArgumentsOfMethod
// ReSharper disable PartialTypeWithSinglePart
// ReSharper disable UnusedAutoPropertyAccessor.Global
// ReSharper disable PreferConcreteValueOverDefault
// ReSharper disable RedundantNameQualifier
// ReSharper disable MemberCanBePrivate.Global
// ReSharper disable CheckNamespace
// ReSharper disable FieldCanBeMadeReadOnly.Global
// ReSharper disable RedundantUsingDirective
// ReSharper disable ConditionIsAlwaysTrueOrFalseAccordingToNullableAPIContract
#pragma warning disable CS8625 // Cannot convert null literal to non-nullable reference type.
#pragma warning disable CS8618
namespace Fantasy
{
    /// <summary>
    /// 发送到 MapScene 请求创建一个新的地图
    /// </summary>
    [Serializable]
    [ProtoContract]
    public partial class MC2M_RequestMapRequest : AMessage, IAddressRequest
    {
        public static MC2M_RequestMapRequest Create(bool autoReturn = true)
        {
            var mC2M_RequestMapRequest = MessageObjectPool<MC2M_RequestMapRequest>.Rent();
            mC2M_RequestMapRequest.AutoReturn = autoReturn;
            
            if (!autoReturn)
            {
                mC2M_RequestMapRequest.SetIsPool(false);
            }
            
            return mC2M_RequestMapRequest;
        }
        
        public void Return()
        {
            if (!AutoReturn)
            {
                SetIsPool(true);
                AutoReturn = true;
            }
            else if (!IsPool())
            {
                return;
            }
            Dispose();
        }

        public void Dispose()
        {
            if (!IsPool()) return; 
            MapLineSlotManagerAddress = default;
            MapLineSlotAddress = default;
            MapLineSlotId = default;
            MapConfigId = default;
            MapLinNumber = default;
            MessageObjectPool<MC2M_RequestMapRequest>.Return(this);
        }
        public uint OpCode() { return InnerOpcode.MC2M_RequestMapRequest; } 
        [ProtoIgnore]
        public M2MC_RequestMapResponse ResponseType { get; set; }
        /// <summary>
        /// MapControlScene下的MapLineSlotManagerComponent的 Address
        /// </summary>
        [ProtoMember(1)]
        public long MapLineSlotManagerAddress { get; set; }
        /// <summary>
        /// MapControlScene下的MapLineSlot的 Address
        /// </summary>
        [ProtoMember(2)]
        public long MapLineSlotAddress { get; set; }
        /// <summary>
        /// MapControlScene下的MapLineSlot.Id
        /// </summary>
        [ProtoMember(3)]
        public long MapLineSlotId { get; set; }
        /// <summary>
        /// 请求创建的地图配置表 Id
        /// </summary>
        [ProtoMember(4)]
        public int MapConfigId { get; set; }
        /// <summary>
        /// 请求的地图线号
        /// </summary>
        [ProtoMember(5)]
        public int MapLinNumber { get; set; }
    }
    [Serializable]
    [ProtoContract]
    public partial class M2MC_RequestMapResponse : AMessage, IAddressResponse
    {
        public static M2MC_RequestMapResponse Create(bool autoReturn = true)
        {
            var m2MC_RequestMapResponse = MessageObjectPool<M2MC_RequestMapResponse>.Rent();
            m2MC_RequestMapResponse.AutoReturn = autoReturn;
            
            if (!autoReturn)
            {
                m2MC_RequestMapResponse.SetIsPool(false);
            }
            
            return m2MC_RequestMapResponse;
        }
        
        public void Return()
        {
            if (!AutoReturn)
            {
                SetIsPool(true);
                AutoReturn = true;
            }
            else if (!IsPool())
            {
                return;
            }
            Dispose();
        }

        public void Dispose()
        {
            if (!IsPool()) return; 
            ErrorCode = 0;
            MapLineId = default;
            MapLineSubSceneAddress = default;
            MapSceneAddress = default;
            MessageObjectPool<M2MC_RequestMapResponse>.Return(this);
        }
        public uint OpCode() { return InnerOpcode.M2MC_RequestMapResponse; } 
        [ProtoMember(1)]
        public uint ErrorCode { get; set; }
        /// <summary>
        /// 分线的 Id
        /// </summary>
        [ProtoMember(2)]
        public long MapLineId { get; set; }
        /// <summary>
        /// 分线的 Address
        /// </summary>
        [ProtoMember(3)]
        public long MapLineSubSceneAddress { get; set; }
        /// <summary>
        /// 分线所属的 MapScene 的 Address
        /// </summary>
        [ProtoMember(4)]
        public long MapSceneAddress { get; set; }
    }
}