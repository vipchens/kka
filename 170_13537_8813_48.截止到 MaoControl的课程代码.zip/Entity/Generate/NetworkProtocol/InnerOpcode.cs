// ReSharper disable InconsistentNaming
namespace Fantasy
{
    /// <summary>
    /// 本代码有编辑器生成,请不要再这里进行编辑。
    /// </summary>
    public static partial class InnerOpcode
    {
        public const uint MC2M_RequestMapRequest = 1073751825;
        public const uint M2MC_RequestMapResponse = 1207969553;
    }
}