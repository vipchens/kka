using Fantasy.Async;
using Fantasy.Entitas;
using Fantasy.Helper;
using Fantasy.Platform.Net;
#pragma warning disable CS8619 // Nullability of reference types in value doesn't match target type.

namespace Fantasy.Hotfix;

public static class MapLineSlotManagerComponentSystem
{
    #region Initialize

    public static void Initialize(this MapLineSlotManagerComponent self, int mapConfigId)
    {
        self.MapConfigId = mapConfigId;
    }

    #endregion

    /// <summary>
    /// 为指定的 Unit 获取负载最低的地图分线，若所有分线均已到了创建的阈值则申请创建新的分线
    /// </summary>
    /// <param name="self"></param>
    /// <param name="unitId"></param>
    /// <param name="sceneConfig"></param>
    /// <returns></returns>
    public static async FTask<(ErrorCode ErrorCode, bool IsCreate, MapLineSlot mapLineSlot)> GetOrCreateMapLine(this MapLineSlotManagerComponent self, long unitId, SceneConfig sceneConfig)
    {
        var isCreate = false;
        var mapConfig = self.Config;
        var mapLineSlotSorted = self.MapLineSlotSorted;
        var mapLineSlot = mapLineSlotSorted.Min;

        if (mapLineSlot == null || mapLineSlot.UnitCount >= mapConfig.CreateLineNum)
        {
            // 当前无分线，或者人数最少的分线已经达到了创建新线的阈值，需要创建一个新分线
            if (mapLineSlotSorted.Count >= mapConfig.MaxLineNum)
            {
                // 分线数量已经到达了配置的上线，拒绝创建。
                return (ErrorCode.MapControl_MapLineCountLimit, false, null);
            }

            // 从回收池里或自动序列化分配一个线号
            var allocLineNumber = self.AllocLineNumber();

            mapLineSlot = Entity.Create<MapLineSlot>(self.Scene, true, true);
            
            mapLineSlot.ExpireTime = 0;
            mapLineSlot.CreateTime = TimeHelper.Now;
            mapLineSlot.LineNumber = allocLineNumber;
            
            mapLineSlot.SceneConfigId = sceneConfig.Id;

            // 向目标 MapScene 发送请求，申请在其上创建一条新的地图子场景分线
            var result = (M2MC_RequestMapResponse)await self.Scene.NetworkMessagingComponent.Call(sceneConfig.Address,
                new MC2M_RequestMapRequest()
                {
                    MapLineSlotId = mapLineSlot.Id,
                    MapLineSlotManagerAddress = self.Address,
                    MapLineSlotAddress = mapLineSlot.Address,
                    MapConfigId = self.MapConfigId,
                    MapLinNumber = allocLineNumber
                });

            if (result.ErrorCode != (uint)ErrorCode.Success)
            {
                // 远端创建失败，销毁创建的MapLineSlot并且要归还线号
                mapLineSlot.Dispose();
                self.FreeLineNumber(allocLineNumber);
                return (ErrorCode.MapControl_RequestMapLineFailed, false, null);
            }
            
            // 将远端返回的子场景地址写入 MapLineSlot
            mapLineSlot.MapLineSubSceneAddress = result.MapLineSubSceneAddress;
            mapLineSlot.MapSceneAddress = result.MapSceneAddress;
            // 登记到分线字典，供后续查询
            self.MapLineSlots.Add(mapLineSlot.Id, mapLineSlot);
            isCreate = true;
        }
        else
        {
            mapLineSlotSorted.Remove(mapLineSlot);
        }

        // 将 UnitId 写入目标分线的 Request 列表作为预占位，防止并发请求超出人数上限
        mapLineSlot.Request[unitId] = TimeHelper.Now + Config.Setting.MapRequestExpirationTime;
        // 重新加入有序的集合
        mapLineSlotSorted.Add(mapLineSlot);
        // 这个是临时，后面要删除的
        await FTask.CompletedTask;
        return (ErrorCode.Success, isCreate, mapLineSlot);
    }

    /// <summary>
    /// 让指定的 Unit 直接加入目标分线，不触发新分线的创建
    /// <para>
    /// 适用于玩家主动选择指定线路的场景（如手动切线）
    /// 全部通过将 UnitId 写入<see cref="MapLineSlot.Request"/> 做为预占位
    /// </para>
    /// </summary>
    /// <param name="self"></param>
    /// <param name="unitId"></param>
    /// <param name="mapLineSlotId"></param>
    /// <returns></returns>
    public static (ErrorCode ErrorCode, MapLineSlot MapLineSlot) GetMapLineById(this MapLineSlotManagerComponent self, long unitId, long mapLineSlotId)
    {
        if (!self.MapLineSlots.TryGetValue(mapLineSlotId, out var mapLineSlot))
        {
            return (ErrorCode.MapControl_NoAvailableMapServer, null);
        }

        if (mapLineSlot.Units.Contains(unitId))
        {
            return (ErrorCode.MapLine_UnitExisting, null);
        }

        if (mapLineSlot.UnitCount > self.Config.MaxPlayerNum)
        {
            return (ErrorCode.MapControl_MapLineCountLimit, null);
        }

        // MapLineSlotSorted 不会自动更新排序，写入数据后要先移除，写人后重新插入刷新排序
        self.MapLineSlotSorted.Remove(mapLineSlot);
        mapLineSlot.Request[unitId] = TimeHelper.Now + Config.Setting.MapRequestExpirationTime;
        self.MapLineSlotSorted.Add(mapLineSlot);
        return (ErrorCode.Success, mapLineSlot);
    }
    
    /// <summary>
    /// 对指定分线在<see cref="MapLineSlotManagerComponent.MapLineSlotSorted"/> 中重新排序
    /// 每次MapLineSlot人数变化都需要要调用此方式，比如UnitJoin、UnitExit
    /// </summary>
    /// <param name="self"></param>
    /// <param name="mapLineSlot"></param>
    public static void MapLineSlotSort(this MapLineSlotManagerComponent self, MapLineSlot mapLineSlot)
    {
        self.MapLineSlotSorted.Remove(mapLineSlot);
        self.MapLineSlotSorted.Add(mapLineSlot);
    }

    #region LineNumber

    /// <summary>
    /// 分配一个现在号
    /// </summary>
    /// <param name="self"></param>
    /// <returns>分配到的线号。</returns>
    private static int AllocLineNumber(this MapLineSlotManagerComponent self)
    {
        if (self.RecycledLineNumbers.TryDequeue(out var lineNumber, out _))
        {
            return lineNumber;
        }

        return self.NextLineNumber++;
    }

    /// <summary>
    /// 回收一个线号，将其归还到回收池，供下次使用
    /// </summary>
    /// <param name="self"></param>
    /// <param name="lineNumber"></param>
    private static void FreeLineNumber(this MapLineSlotManagerComponent self, int lineNumber)
    {
        self.RecycledLineNumbers.Enqueue(lineNumber, lineNumber);
    }

    #endregion
}