using Fantasy.Async;
using Fantasy.Entitas;
using Fantasy.Platform.Net;

namespace Fantasy.Hotfix;

public static class MapControlManagerComponentSystem
{
    /// <summary>
    /// 加载或热重载所有地图 Scene 的配置到优先队列
    /// 若队列中已有数据（热重载场景），会先将当前人数状态保存到临时字典
    /// 再按最新配置表重建队列，已存在的 Scene 恢复原有人数，新增的 Scene 初始人数为0
    /// </summary>
    /// <param name="self"></param>
    public static void LoadMapScenes(this MapControlManagerComponent self)
    {
        var dic = new Dictionary<uint, int>();

        // 为了支持热重载，可以先将当然 Scene 的所有人数状态临时增加到一个字典中
        // 重建队列后恢复，避免人数数据丢失
        while (self.MapScenes.TryDequeue(out var sceneConfig,out var playerCount))
        {
            dic.Add(sceneConfig.Id, playerCount);
        }
        
        // 清空队列，按照最新的配置表重建。
        self.MapScenes.Clear();
        // 从配置表获取所有 Map 类型的 Scene 配置。
        var mapScenes = SceneConfigData.Instance.GetSceneBySceneType(SceneType.Map);

        foreach (var sceneConfig in mapScenes)
        {
            if (dic.TryGetValue(sceneConfig.Id, out var playerCount))
            {
                // 该 Scene 是热重载前已经存在的，恢复原有人数状态。
                self.MapScenes.Enqueue(sceneConfig,0);
                continue;
            }
            
            // 该 Scene 是新增的，初始人数为0。
            self.MapScenes.Enqueue(sceneConfig,0);
        }
    }

    /// <summary>
    /// 为指定地图配置请求一个负载最低的分线。
    /// 从 MapScenes 优先队列中取出当前人数最少的 Scene，找到或创建对应的。
    /// </summary>
    /// <param name="self"></param>
    /// <param name="unitId"></param>
    /// <param name="mapConfigId"></param>
    /// <returns></returns>
    public static async FTask<ErrorCode> GetMapLine(this MapControlManagerComponent self, long unitId, int mapConfigId)
    {
        // 从优先队列中取出当前负载最小的 MapScene
        if (!self.MapScenes.TryDequeue(out var sceneConfig, out var currentPlayerCount))
        {
            // 这里当前没有可用的地图服务器了。
            return ErrorCode.MapControl_NoAvailableMapServer;
        }

        // 根据 MapConfigId 找到对应的mapLineSlotManagerComponent，不存在就创建一个新的
        if (!self.MapLineSlots.TryGetValue(mapConfigId, out var mapLineSlotManagerComponent))
        {
            mapLineSlotManagerComponent = Entity.Create<MapLineSlotManagerComponent>(self.Scene, true, true);
            mapLineSlotManagerComponent.Initialize(mapConfigId);
            self.MapLineSlots.Add(mapConfigId, mapLineSlotManagerComponent);
        }

        // 向目标 Scene 请求一个地图分线
        var requestResult = await mapLineSlotManagerComponent.GetOrCreateMapLine(unitId, sceneConfig);
        if (requestResult.ErrorCode != ErrorCode.Success)
        {
            // 就算是失败了，也要重新入队计算一下实时人数才了。不然这个 Scene 就不被丢弃掉了
            self.UpdateMapScene(sceneConfig);
            return requestResult.ErrorCode;
        }

        // 如果是新创建的分线，需要加入到MapLineSlotBySceneConfig 中，供 UpdateMapScene 统计人数使用
        if (requestResult.IsCreate)
        {
            self.MapLineSlotBySceneConfig.Add(sceneConfig.Id, requestResult.mapLineSlot);
        }

        // 请求创建成功后，用该 Scene 下的所有分线重新进行实时计算并且入队
        self.UpdateMapScene(sceneConfig);
        return ErrorCode.Success;
    }

    /// <summary>
    /// 获得一个指定的地图分线
    /// 方法直接指定目标分线 Id 加入，不会触发新分线的创建
    /// </summary>
    /// <param name="self"></param>
    /// <param name="unitId"></param>
    /// <param name="mapConfigId"></param>
    /// <param name="mapLineSlotId"></param>
    /// <returns></returns>
    public static ErrorCode GetMapLineBySlotId(this MapControlManagerComponent self, long unitId, int mapConfigId, long mapLineSlotId)
    {
        if (!self.MapLineSlots.TryGetValue(mapConfigId, out var mapLineSlotManagerComponent))
        {
            return ErrorCode.MapControl_NoAvailableMapServer;
        }

        var result = mapLineSlotManagerComponent.GetMapLineById(unitId, mapLineSlotId);
        if (result.ErrorCode != ErrorCode.Success)
        {
            return result.ErrorCode;
        }

        return ErrorCode.Success;
    }
    

    /// <summary>
    /// 重新计算指定的 Scene 下的所有分线的实时总人数，并将其以最新的加入到优先队列中
    /// </summary>
    /// <param name="self"></param>
    /// <param name="sceneConfig"></param>
    public static void UpdateMapScene(this MapControlManagerComponent self, SceneConfig sceneConfig)
    {
        var playerCount = 0;
        
        if (self.MapLineSlotBySceneConfig.TryGetValue(sceneConfig.Id, out var mapLineSlots))
        {
            foreach (var mapLineSlot in mapLineSlots)
            {
                playerCount += mapLineSlot.UnitCount;
            }
        }
        
        self.MapScenes.Enqueue(sceneConfig, playerCount);
    }
}