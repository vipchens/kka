using Fantasy.DataStructure.Collection;
using Fantasy.Entitas.Interface;
using Fantasy.Helper;
#pragma warning disable CS8625 // Cannot convert null literal to non-nullable reference type.

namespace Fantasy.Hotfix;

public sealed class MapLineSlotAwakeSystem : AwakeSystem<MapLineSlot>
{
    protected override void Awake(MapLineSlot self)
    {
        self.TimerId = self.Scene.TimerComponent.Net.RepeatedTimer(Config.Setting.MapRequestClearTime, self.ClearRequest);
    }
}

public sealed class MapLineSlotDestroySystem : DestroySystem<MapLineSlot>
{
    protected override void Destroy(MapLineSlot self)
    {
        if (self.TimerId != 0)
        {
            self.Scene.TimerComponent.Net.Remove(ref self.TimerId);
        }
        
        self.CreateTime = 0;
        self.ExpireTime = 0;
        self.LineNumber = 0;
        
        self.Units.Clear();
        self.Request.Clear();
        
        self.MapLineSlotManagerComponent = null;
    }
}

public static class MapLineSlotSystem
{
    /// <summary>
    /// 清理<see cref="MapLineSlot.Request"/> 中过期的请求条目
    /// 有定时器周日性的调用，将过期时间早于当前时间的条目从请求列表中移除
    /// </summary>
    /// <param name="self"></param>
    public static void ClearRequest(this MapLineSlot self)
    {
        if (self.Request.Count == 0)
        {
            return;
        }

        var now = TimeHelper.Now;
        using var hashSet = HashSetPool<long>.Create();
        
        foreach (var keyValuePair in self.Request)
        {
            if (keyValuePair.Value < now)
            {
                hashSet.Remove(keyValuePair.Key);
            }
        }
        
        foreach (var unitId in hashSet)
        {
            self.Request.Remove(unitId);
        }
    }

    /// <summary>
    /// 将已完成的 Unit 从请求列表中迁移到在线列表
    /// </summary>
    /// <param name="self"></param>
    /// <param name="unitId"></param>
    /// <returns></returns>
    public static uint UnitJoin(this MapLineSlot self, long unitId)
    {
        if (unitId == 0)
        {
            return (uint)ErrorCode.Success;
        }

        if (!self.Request.Remove(unitId))
        {
            return (uint)ErrorCode.MapLine_NotInTheRequestList;
        }
        
        self.Units.Add(unitId);
        self.MapLineSlotManagerComponent.MapLineSlotSort(self);
        self.Scene.GetComponent<MapControlManagerComponent>().UpdateMapScene(self.SceneConfig);
        return (uint)ErrorCode.Success;
    }
    
    /// <summary>
    /// 将 Unit 从分线的请求列表中和在线列中移除
    /// </summary>
    /// <param name="self"></param>
    /// <param name="unitId"></param>
    public static void UnitExit(this MapLineSlot self, long unitId)
    {
        if (unitId == 0)
        {
            Log.Warning($"[MapLineSlot][UnitExit] UnitId:{unitId} cannot be 0");
            return;
        }

        self.Request.Remove(unitId);
        self.Units.Remove(unitId);
        self.MapLineSlotManagerComponent.MapLineSlotSort(self);
        self.Scene.GetComponent<MapControlManagerComponent>().UpdateMapScene(self.SceneConfig);
    }
}