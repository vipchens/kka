using Fantasy.Async;

namespace Fantasy.Hotfix;

public static class MapLineManageComponentSystem
{
    /// <summary>
    /// 在本 Map 服务器上创建一条新的地图分线（SubScene），并将其注册到分线列表中。
    /// </summary>
    /// <param name="self"></param>
    /// <param name="mapLineSlotId"></param>
    /// <param name="mapLineSlotManagerAddress"></param>
    /// <param name="mapLineSlotAddress"></param>
    /// <param name="mapConfigId"></param>
    /// <param name="mapLineNumber"></param>
    /// <returns></returns>
    public static async FTask<SubScene> RequestMapLine(this MapLineManageComponent self, long mapLineSlotId,
        long mapLineSlotManagerAddress, long mapLineSlotAddress, int mapConfigId, int mapLineNumber)
    {
        var newSubScene = await Scene.CreateSubScene(self.Scene, SceneType.Map, OnSubSceneSetup);

        async FTask OnSubSceneSetup(SubScene subScene, Scene scene)
        {
            // 这里就可以提前挂载一些非常核心的组件，并且不需要外面挂载的
            await FTask.CompletedTask;
        }

        self.Lines.Add(newSubScene.Id, newSubScene);
        return newSubScene;
    }

    /// <summary>
    /// 移除指定的地图分线，降对应<see cref="SubScene"/> 从列表中删除并销毁
    /// </summary>
    /// <param name="self"></param>
    /// <param name="mapLineId"></param>
    public static void RemoveMapLine(this MapLineManageComponent self, long mapLineId)
    {
        if (!self.Lines.Remove(mapLineId, out var subScene))
        {
            return;
        }
        
        subScene.Dispose();
    }
}