using Fantasy.Async;
using Fantasy.Network.Interface;

namespace Fantasy.Hotfix;

public sealed class MC2M_RequestMapRequestHandler : AddressRPC<Scene, MC2M_RequestMapRequest, M2MC_RequestMapResponse>
{
    protected override async FTask Run(Scene entity, MC2M_RequestMapRequest request, M2MC_RequestMapResponse response, Action reply)
    {
        await FTask.CompletedTask;
    }
}