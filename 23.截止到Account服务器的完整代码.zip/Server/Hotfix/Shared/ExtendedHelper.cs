using Fantasy.Entitas;
// ReSharper disable ConditionIsAlwaysTrueOrFalseAccordingToNullableAPIContract

namespace Fantasy.Hotfix;

/// <summary>
/// 扩展方法静态类
/// </summary>
public static class ExtendedHelper
{
    /// <summary>
    /// 设置父实体的存活时长，到期后会自动调用父实体的Dispose方法销毁父实体。
    /// 若有定时器在运行，会先取消旧的定时器在重新计时。
    /// </summary>
    /// <param name="self"></param>
    /// <param name="milliseconds">延迟的时长，单位:毫秒</param>
    public static void SetLifeTime(this Entity self, long milliseconds)
    {
        var lifeTimeComponent = self.GetComponent<LifeTimeComponent>() ?? self.AddComponent<LifeTimeComponent>();
        lifeTimeComponent.SetLifeTime(milliseconds);
    }
}