using Fantasy.Async;
using Fantasy.Network;
using Fantasy.Network.Interface;

namespace Fantasy.Hotfix;

public sealed class C2A_AddRecentServerHandler : Message<C2A_AddRecentServer>
{
    protected override async FTask Run(Session session, C2A_AddRecentServer message)
    {
        await AccountHelper.AddRecentServer(session.Scene, message.AccountId, message.ServerConfigId);
    }
}