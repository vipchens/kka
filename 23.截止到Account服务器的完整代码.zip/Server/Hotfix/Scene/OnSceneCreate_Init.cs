using Fantasy.Async;
using Fantasy.Event;

namespace Fantasy.Hotfix;

public sealed class OnSceneCreate_Init : AsyncEventSystem<OnCreateScene>
{
    protected override async FTask Handler(OnCreateScene self)
    {
        var scene = self.Scene;

        switch (scene.SceneType)
        {
            case SceneType.Account:
            {
                // 账号管理组件，用于注册和登录。
                scene.AddComponent<AccountManageComponent>();
                // 账号 ToKen 组件，用于生成或验证 ToKen。
                scene.AddComponent<AccountJWTComponent>();
                break;
            }
        }
        
        await FTask.CompletedTask;
    }
}