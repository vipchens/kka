namespace Fantasy.Table;

public partial class ServerTable
{
    private List<ServerList>? _serverList;
    
    public List<ServerList> GetServerList()
    {
        if (_serverList == null)
        {
            _serverList = new List<ServerList>();
            foreach (var serverInfo in _dataList)
            {
                _serverList.Add(new ServerList()
                {
                    Name = serverInfo.Name,
                    Group = serverInfo.Group,
                    Address = serverInfo.Address,
                    Recommend = serverInfo.Recommend
                });
            }
        }
        
        return _serverList;
    }

    public bool IsExist(int serverConfigId)
    {
        return _dataMap.ContainsKey(serverConfigId);
    }
}