// ReSharper disable InconsistentNaming
namespace Fantasy
{
    /// <summary>
    /// 本代码有编辑器生成,请不要再这里进行编辑。
    /// </summary>
    public static partial class OuterOpcode
    {
        public const uint C2A_RegisterAccountRequest = 268445457;
        public const uint A2C_RegisterAccountResponse = 402663185;
        public const uint C2A_LoginAccountRequest = 268445458;
        public const uint A2C_LoginAccountesponse = 402663186;
        public const uint C2A_AddRecentServer = 134227729;
    }
}