using LightProto;
using System;
using MemoryPack;
using System.Collections.Generic;
using Fantasy;
using Fantasy.Pool;
using Fantasy.Network.Interface;
using Fantasy.Serialize;

#pragma warning disable CS8625 // Cannot convert null literal to non-nullable reference type.
#pragma warning disable CS8618
// ReSharper disable InconsistentNaming
// ReSharper disable CollectionNeverUpdated.Global
// ReSharper disable RedundantTypeArgumentsOfMethod
// ReSharper disable PartialTypeWithSinglePart
// ReSharper disable UnusedAutoPropertyAccessor.Global
// ReSharper disable PreferConcreteValueOverDefault
// ReSharper disable RedundantNameQualifier
// ReSharper disable MemberCanBePrivate.Global
// ReSharper disable CheckNamespace
// ReSharper disable FieldCanBeMadeReadOnly.Global
// ReSharper disable RedundantUsingDirective
// ReSharper disable ConditionIsAlwaysTrueOrFalseAccordingToNullableAPIContract
namespace Fantasy
{
    /// <summary>
    /// 注册一个新账号
    /// </summary>
    [Serializable]
    [ProtoContract]
    public partial class C2A_RegisterAccountRequest : AMessage, IRequest
    {
        public static C2A_RegisterAccountRequest Create(bool autoReturn = true)
        {
            var c2A_RegisterAccountRequest = MessageObjectPool<C2A_RegisterAccountRequest>.Rent();
            c2A_RegisterAccountRequest.AutoReturn = autoReturn;
            
            if (!autoReturn)
            {
                c2A_RegisterAccountRequest.SetIsPool(false);
            }
            
            return c2A_RegisterAccountRequest;
        }
        
        public void Return()
        {
            if (!AutoReturn)
            {
                SetIsPool(true);
                AutoReturn = true;
            }
            else if (!IsPool())
            {
                return;
            }
            Dispose();
        }

        public void Dispose()
        {
            if (!IsPool()) return; 
            Account = default;
            Password = default;
            MessageObjectPool<C2A_RegisterAccountRequest>.Return(this);
        }
        public uint OpCode() { return OuterOpcode.C2A_RegisterAccountRequest; } 
        [ProtoIgnore]
        public A2C_RegisterAccountResponse ResponseType { get; set; }
        [ProtoMember(1)]
        public string Account { get; set; }
        [ProtoMember(2)]
        public string Password { get; set; }
    }
    [Serializable]
    [ProtoContract]
    public partial class A2C_RegisterAccountResponse : AMessage, IResponse
    {
        public static A2C_RegisterAccountResponse Create(bool autoReturn = true)
        {
            var a2C_RegisterAccountResponse = MessageObjectPool<A2C_RegisterAccountResponse>.Rent();
            a2C_RegisterAccountResponse.AutoReturn = autoReturn;
            
            if (!autoReturn)
            {
                a2C_RegisterAccountResponse.SetIsPool(false);
            }
            
            return a2C_RegisterAccountResponse;
        }
        
        public void Return()
        {
            if (!AutoReturn)
            {
                SetIsPool(true);
                AutoReturn = true;
            }
            else if (!IsPool())
            {
                return;
            }
            Dispose();
        }

        public void Dispose()
        {
            if (!IsPool()) return; 
            ErrorCode = 0;
            MessageObjectPool<A2C_RegisterAccountResponse>.Return(this);
        }
        public uint OpCode() { return OuterOpcode.A2C_RegisterAccountResponse; } 
        [ProtoMember(1)]
        public uint ErrorCode { get; set; }
    }
    /// <summary>
    /// 登录账号
    /// </summary>
    [Serializable]
    [ProtoContract]
    public partial class C2A_LoginAccountRequest : AMessage, IRequest
    {
        public static C2A_LoginAccountRequest Create(bool autoReturn = true)
        {
            var c2A_LoginAccountRequest = MessageObjectPool<C2A_LoginAccountRequest>.Rent();
            c2A_LoginAccountRequest.AutoReturn = autoReturn;
            
            if (!autoReturn)
            {
                c2A_LoginAccountRequest.SetIsPool(false);
            }
            
            return c2A_LoginAccountRequest;
        }
        
        public void Return()
        {
            if (!AutoReturn)
            {
                SetIsPool(true);
                AutoReturn = true;
            }
            else if (!IsPool())
            {
                return;
            }
            Dispose();
        }

        public void Dispose()
        {
            if (!IsPool()) return; 
            Account = default;
            Password = default;
            MessageObjectPool<C2A_LoginAccountRequest>.Return(this);
        }
        public uint OpCode() { return OuterOpcode.C2A_LoginAccountRequest; } 
        [ProtoIgnore]
        public A2C_LoginAccountesponse ResponseType { get; set; }
        [ProtoMember(1)]
        public string Account { get; set; }
        [ProtoMember(2)]
        public string Password { get; set; }
    }
    [Serializable]
    [ProtoContract]
    public partial class A2C_LoginAccountesponse : AMessage, IResponse
    {
        public static A2C_LoginAccountesponse Create(bool autoReturn = true)
        {
            var a2C_LoginAccountesponse = MessageObjectPool<A2C_LoginAccountesponse>.Rent();
            a2C_LoginAccountesponse.AutoReturn = autoReturn;
            
            if (!autoReturn)
            {
                a2C_LoginAccountesponse.SetIsPool(false);
            }
            
            return a2C_LoginAccountesponse;
        }
        
        public void Return()
        {
            if (!AutoReturn)
            {
                SetIsPool(true);
                AutoReturn = true;
            }
            else if (!IsPool())
            {
                return;
            }
            Dispose();
        }

        public void Dispose()
        {
            if (!IsPool()) return; 
            ErrorCode = 0;
            AccountId = default;
            Token = default;
            List = null;
            RecentServers.Clear();
            MessageObjectPool<A2C_LoginAccountesponse>.Return(this);
        }
        public uint OpCode() { return OuterOpcode.A2C_LoginAccountesponse; } 
        [ProtoMember(1)]
        public uint ErrorCode { get; set; }
        [ProtoMember(2)]
        public long AccountId { get; set; }
        [ProtoMember(3)]
        public string Token { get; set; }
        [ProtoMember(4)]
        public List<ServerList> List { get; set; }
        [ProtoMember(5)]
        public List<int> RecentServers { get; set; } = new List<int>();
    }
    /// <summary>
    /// 服务器列表信息
    /// </summary>
    [Serializable]
    [ProtoContract]
    public partial class ServerList : AMessage, IDisposable
    {
        public static ServerList Create(bool autoReturn = true)
        {
            var serverList = MessageObjectPool<ServerList>.Rent();
            serverList.AutoReturn = autoReturn;
            
            if (!autoReturn)
            {
                serverList.SetIsPool(false);
            }
            
            return serverList;
        }
        
        public void Return()
        {
            if (!AutoReturn)
            {
                SetIsPool(true);
                AutoReturn = true;
            }
            else if (!IsPool())
            {
                return;
            }
            Dispose();
        }

        public void Dispose()
        {
            if (!IsPool()) return; 
            Name = default;
            Group = default;
            Address = default;
            Recommend = default;
            MessageObjectPool<ServerList>.Return(this);
        }
        /// <summary>
        /// 服务器名字
        /// </summary>
        [ProtoMember(1)]
        public string Name { get; set; }
        /// <summary>
        /// 服务器分组
        /// </summary>
        [ProtoMember(2)]
        public string Group { get; set; }
        /// <summary>
        /// 服务器地址
        /// </summary>
        [ProtoMember(3)]
        public string Address { get; set; }
        /// <summary>
        /// 是否推荐服务器
        /// </summary>
        [ProtoMember(4)]
        public bool Recommend { get; set; }
    }
    /// <summary>
    /// 同步当前选择的服务器
    /// </summary>
    [Serializable]
    [ProtoContract]
    public partial class C2A_AddRecentServer : AMessage, IMessage
    {
        public static C2A_AddRecentServer Create(bool autoReturn = true)
        {
            var c2A_AddRecentServer = MessageObjectPool<C2A_AddRecentServer>.Rent();
            c2A_AddRecentServer.AutoReturn = autoReturn;
            
            if (!autoReturn)
            {
                c2A_AddRecentServer.SetIsPool(false);
            }
            
            return c2A_AddRecentServer;
        }
        
        public void Return()
        {
            if (!AutoReturn)
            {
                SetIsPool(true);
                AutoReturn = true;
            }
            else if (!IsPool())
            {
                return;
            }
            Dispose();
        }

        public void Dispose()
        {
            if (!IsPool()) return; 
            AccountId = default;
            ServerConfigId = default;
            MessageObjectPool<C2A_AddRecentServer>.Return(this);
        }
        public uint OpCode() { return OuterOpcode.C2A_AddRecentServer; } 
        [ProtoMember(1)]
        public long AccountId { get; set; }
        [ProtoMember(2)]
        public int ServerConfigId { get; set; }
    }
}