@echo off
dotnet App\Luban.dll ^
    -t client ^
    -d bin ^
    -c cs-bin ^
    --conf luban.conf ^
    -x outputDataDir=..\..\Client\Config ^
    -x outputCodeDir=..\..\Client\Generate\Config ^
    -x outputSaver.bin.cleanUpOutputDir=0 ^
    -x outputSaver.cs-bin.cleanUpOutputDir=0
