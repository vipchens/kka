@echo off
echo Starting parallel generation...

REM 并行启动两个进程
start /B "" cmd /c gen_client.bat ^> client_output.log 2^>^&1
start /B "" cmd /c gen_server.bat ^> server_output.log 2^>^&1

REM 等待所有后台进程完成
:wait_loop
tasklist /FI "IMAGENAME eq dotnet.exe" 2>nul | find "dotnet.exe" >nul
if %ERRORLEVEL% EQU 0 (
    timeout /t 1 /nobreak >nul
    goto wait_loop
)

echo.
echo Generation completed!
echo.
echo ========== Client Output ==========
type client_output.log 2>nul
echo.
echo ========== Server Output ==========
type server_output.log 2>nul
echo.

pause
