#!/bin/bash

dotnet App/Luban.dll \
    -t server \
    -d bin \
    -d json \
    -c cs-bin \
    --conf luban.conf \
    -x bin.outputDataDir=../../Config/Binary \
    -x json.outputDataDir=../../Config/Json \
    -x outputCodeDir=../../Server/Entity/Generate/Config \
    -x outputSaver.bin.cleanUpOutputDir=0 \
    -x outputSaver.json.cleanUpOutputDir=0 \
    -x outputSaver.cs-bin.cleanUpOutputDir=0