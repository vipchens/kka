#!/bin/bash

echo "Starting parallel generation..."

# 并行执行 client 和 server 脚本
./gen_client.sh &
CLIENT_PID=$!

./gen_server.sh &
SERVER_PID=$!

# 等待两个进程完成
wait $CLIENT_PID
CLIENT_EXIT=$?

wait $SERVER_PID
SERVER_EXIT=$?

# 检查执行结果
if [ $CLIENT_EXIT -eq 0 ] && [ $SERVER_EXIT -eq 0 ]; then
    echo "All generation completed successfully!"
    exit 0
else
    echo "Generation failed!"
    [ $CLIENT_EXIT -ne 0 ] && echo "Client generation failed with code $CLIENT_EXIT"
    [ $SERVER_EXIT -ne 0 ] && echo "Server generation failed with code $SERVER_EXIT"
    exit 1
fi
