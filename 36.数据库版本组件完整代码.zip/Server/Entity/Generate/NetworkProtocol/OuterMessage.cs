using LightProto;
using System;
using MemoryPack;
using System.Collections.Generic;
using Fantasy;
using Fantasy.Pool;
using Fantasy.Network.Interface;
using Fantasy.Serialize;

#pragma warning disable CS8625 // Cannot convert null literal to non-nullable reference type.
#pragma warning disable CS8618
// ReSharper disable InconsistentNaming
// ReSharper disable CollectionNeverUpdated.Global
// ReSharper disable RedundantTypeArgumentsOfMethod
// ReSharper disable PartialTypeWithSinglePart
// ReSharper disable UnusedAutoPropertyAccessor.Global
// ReSharper disable PreferConcreteValueOverDefault
// ReSharper disable RedundantNameQualifier
// ReSharper disable MemberCanBePrivate.Global
// ReSharper disable CheckNamespace
// ReSharper disable FieldCanBeMadeReadOnly.Global
// ReSharper disable RedundantUsingDirective
// ReSharper disable ConditionIsAlwaysTrueOrFalseAccordingToNullableAPIContract
namespace Fantasy
{
    /// <summary>
    /// 注册一个新账号
    /// </summary>
    [Serializable]
    [ProtoContract]
    public partial class C2A_RegisterAccountRequest : AMessage, IRequest
    {
        public static C2A_RegisterAccountRequest Create(bool autoReturn = true)
        {
            var c2A_RegisterAccountRequest = MessageObjectPool<C2A_RegisterAccountRequest>.Rent();
            c2A_RegisterAccountRequest.AutoReturn = autoReturn;
            
            if (!autoReturn)
            {
                c2A_RegisterAccountRequest.SetIsPool(false);
            }
            
            return c2A_RegisterAccountRequest;
        }
        
        public void Return()
        {
            if (!AutoReturn)
            {
                SetIsPool(true);
                AutoReturn = true;
            }
            else if (!IsPool())
            {
                return;
            }
            Dispose();
        }

        public void Dispose()
        {
            if (!IsPool()) return; 
            Account = default;
            Password = default;
            MessageObjectPool<C2A_RegisterAccountRequest>.Return(this);
        }
        public uint OpCode() { return OuterOpcode.C2A_RegisterAccountRequest; } 
        [ProtoIgnore]
        public A2C_RegisterAccountResponse ResponseType { get; set; }
        [ProtoMember(1)]
        public string Account { get; set; }
        [ProtoMember(2)]
        public string Password { get; set; }
    }
    [Serializable]
    [ProtoContract]
    public partial class A2C_RegisterAccountResponse : AMessage, IResponse
    {
        public static A2C_RegisterAccountResponse Create(bool autoReturn = true)
        {
            var a2C_RegisterAccountResponse = MessageObjectPool<A2C_RegisterAccountResponse>.Rent();
            a2C_RegisterAccountResponse.AutoReturn = autoReturn;
            
            if (!autoReturn)
            {
                a2C_RegisterAccountResponse.SetIsPool(false);
            }
            
            return a2C_RegisterAccountResponse;
        }
        
        public void Return()
        {
            if (!AutoReturn)
            {
                SetIsPool(true);
                AutoReturn = true;
            }
            else if (!IsPool())
            {
                return;
            }
            Dispose();
        }

        public void Dispose()
        {
            if (!IsPool()) return; 
            ErrorCode = 0;
            MessageObjectPool<A2C_RegisterAccountResponse>.Return(this);
        }
        public uint OpCode() { return OuterOpcode.A2C_RegisterAccountResponse; } 
        [ProtoMember(1)]
        public uint ErrorCode { get; set; }
    }
    /// <summary>
    /// 登录账号
    /// </summary>
    [Serializable]
    [ProtoContract]
    public partial class C2A_LoginAccountRequest : AMessage, IRequest
    {
        public static C2A_LoginAccountRequest Create(bool autoReturn = true)
        {
            var c2A_LoginAccountRequest = MessageObjectPool<C2A_LoginAccountRequest>.Rent();
            c2A_LoginAccountRequest.AutoReturn = autoReturn;
            
            if (!autoReturn)
            {
                c2A_LoginAccountRequest.SetIsPool(false);
            }
            
            return c2A_LoginAccountRequest;
        }
        
        public void Return()
        {
            if (!AutoReturn)
            {
                SetIsPool(true);
                AutoReturn = true;
            }
            else if (!IsPool())
            {
                return;
            }
            Dispose();
        }

        public void Dispose()
        {
            if (!IsPool()) return; 
            Account = default;
            Password = default;
            MessageObjectPool<C2A_LoginAccountRequest>.Return(this);
        }
        public uint OpCode() { return OuterOpcode.C2A_LoginAccountRequest; } 
        [ProtoIgnore]
        public A2C_LoginAccountResponse ResponseType { get; set; }
        [ProtoMember(1)]
        public string Account { get; set; }
        [ProtoMember(2)]
        public string Password { get; set; }
    }
    [Serializable]
    [ProtoContract]
    public partial class A2C_LoginAccountResponse : AMessage, IResponse
    {
        public static A2C_LoginAccountResponse Create(bool autoReturn = true)
        {
            var a2C_LoginAccountResponse = MessageObjectPool<A2C_LoginAccountResponse>.Rent();
            a2C_LoginAccountResponse.AutoReturn = autoReturn;
            
            if (!autoReturn)
            {
                a2C_LoginAccountResponse.SetIsPool(false);
            }
            
            return a2C_LoginAccountResponse;
        }
        
        public void Return()
        {
            if (!AutoReturn)
            {
                SetIsPool(true);
                AutoReturn = true;
            }
            else if (!IsPool())
            {
                return;
            }
            Dispose();
        }

        public void Dispose()
        {
            if (!IsPool()) return; 
            ErrorCode = 0;
            AccountId = default;
            Token = default;
            List = null;
            RecentServers.Clear();
            MessageObjectPool<A2C_LoginAccountResponse>.Return(this);
        }
        public uint OpCode() { return OuterOpcode.A2C_LoginAccountResponse; } 
        [ProtoMember(1)]
        public uint ErrorCode { get; set; }
        [ProtoMember(2)]
        public long AccountId { get; set; }
        [ProtoMember(3)]
        public string Token { get; set; }
        [ProtoMember(4)]
        public List<ServerList> List { get; set; }
        [ProtoMember(5)]
        public List<int> RecentServers { get; set; } = new List<int>();
    }
    /// <summary>
    /// 服务器列表信息
    /// </summary>
    [Serializable]
    [ProtoContract]
    public partial class ServerList : AMessage, IDisposable
    {
        public static ServerList Create(bool autoReturn = true)
        {
            var serverList = MessageObjectPool<ServerList>.Rent();
            serverList.AutoReturn = autoReturn;
            
            if (!autoReturn)
            {
                serverList.SetIsPool(false);
            }
            
            return serverList;
        }
        
        public void Return()
        {
            if (!AutoReturn)
            {
                SetIsPool(true);
                AutoReturn = true;
            }
            else if (!IsPool())
            {
                return;
            }
            Dispose();
        }

        public void Dispose()
        {
            if (!IsPool()) return; 
            Id = default;
            Name = default;
            Group = default;
            Address = default;
            Recommend = default;
            MessageObjectPool<ServerList>.Return(this);
        }
        /// <summary>
        /// Id
        /// </summary>
        [ProtoMember(1)]
        public int Id { get; set; }
        /// <summary>
        /// 服务器名字
        /// </summary>
        [ProtoMember(2)]
        public string Name { get; set; }
        /// <summary>
        /// 服务器分组
        /// </summary>
        [ProtoMember(3)]
        public string Group { get; set; }
        /// <summary>
        /// 服务器地址
        /// </summary>
        [ProtoMember(4)]
        public string Address { get; set; }
        /// <summary>
        /// 是否推荐服务器
        /// </summary>
        [ProtoMember(5)]
        public bool Recommend { get; set; }
    }
    /// <summary>
    /// 同步当前选择的服务器
    /// </summary>
    [Serializable]
    [ProtoContract]
    public partial class C2A_AddRecentServerRequest : AMessage, IRequest
    {
        public static C2A_AddRecentServerRequest Create(bool autoReturn = true)
        {
            var c2A_AddRecentServerRequest = MessageObjectPool<C2A_AddRecentServerRequest>.Rent();
            c2A_AddRecentServerRequest.AutoReturn = autoReturn;
            
            if (!autoReturn)
            {
                c2A_AddRecentServerRequest.SetIsPool(false);
            }
            
            return c2A_AddRecentServerRequest;
        }
        
        public void Return()
        {
            if (!AutoReturn)
            {
                SetIsPool(true);
                AutoReturn = true;
            }
            else if (!IsPool())
            {
                return;
            }
            Dispose();
        }

        public void Dispose()
        {
            if (!IsPool()) return; 
            AccountId = default;
            ServerConfigId = default;
            MessageObjectPool<C2A_AddRecentServerRequest>.Return(this);
        }
        public uint OpCode() { return OuterOpcode.C2A_AddRecentServerRequest; } 
        [ProtoIgnore]
        public A2C_AddRecentServerResponse ResponseType { get; set; }
        [ProtoMember(1)]
        public long AccountId { get; set; }
        [ProtoMember(2)]
        public int ServerConfigId { get; set; }
    }
    [Serializable]
    [ProtoContract]
    public partial class A2C_AddRecentServerResponse : AMessage, IResponse
    {
        public static A2C_AddRecentServerResponse Create(bool autoReturn = true)
        {
            var a2C_AddRecentServerResponse = MessageObjectPool<A2C_AddRecentServerResponse>.Rent();
            a2C_AddRecentServerResponse.AutoReturn = autoReturn;
            
            if (!autoReturn)
            {
                a2C_AddRecentServerResponse.SetIsPool(false);
            }
            
            return a2C_AddRecentServerResponse;
        }
        
        public void Return()
        {
            if (!AutoReturn)
            {
                SetIsPool(true);
                AutoReturn = true;
            }
            else if (!IsPool())
            {
                return;
            }
            Dispose();
        }

        public void Dispose()
        {
            if (!IsPool()) return; 
            ErrorCode = 0;
            MessageObjectPool<A2C_AddRecentServerResponse>.Return(this);
        }
        public uint OpCode() { return OuterOpcode.A2C_AddRecentServerResponse; } 
        [ProtoMember(1)]
        public uint ErrorCode { get; set; }
    }
    /// <summary>
    /// 进入到Gate服务器
    /// </summary>
    [Serializable]
    [ProtoContract]
    public partial class C2G_EnterRequest : AMessage, IRequest
    {
        public static C2G_EnterRequest Create(bool autoReturn = true)
        {
            var c2G_EnterRequest = MessageObjectPool<C2G_EnterRequest>.Rent();
            c2G_EnterRequest.AutoReturn = autoReturn;
            
            if (!autoReturn)
            {
                c2G_EnterRequest.SetIsPool(false);
            }
            
            return c2G_EnterRequest;
        }
        
        public void Return()
        {
            if (!AutoReturn)
            {
                SetIsPool(true);
                AutoReturn = true;
            }
            else if (!IsPool())
            {
                return;
            }
            Dispose();
        }

        public void Dispose()
        {
            if (!IsPool()) return; 
            ToKen = default;
            MessageObjectPool<C2G_EnterRequest>.Return(this);
        }
        public uint OpCode() { return OuterOpcode.C2G_EnterRequest; } 
        [ProtoIgnore]
        public G2C_EnterResponse ResponseType { get; set; }
        [ProtoMember(1)]
        public string ToKen { get; set; }
    }
    [Serializable]
    [ProtoContract]
    public partial class G2C_EnterResponse : AMessage, IResponse
    {
        public static G2C_EnterResponse Create(bool autoReturn = true)
        {
            var g2C_EnterResponse = MessageObjectPool<G2C_EnterResponse>.Rent();
            g2C_EnterResponse.AutoReturn = autoReturn;
            
            if (!autoReturn)
            {
                g2C_EnterResponse.SetIsPool(false);
            }
            
            return g2C_EnterResponse;
        }
        
        public void Return()
        {
            if (!AutoReturn)
            {
                SetIsPool(true);
                AutoReturn = true;
            }
            else if (!IsPool())
            {
                return;
            }
            Dispose();
        }

        public void Dispose()
        {
            if (!IsPool()) return; 
            ErrorCode = 0;
            MessageObjectPool<G2C_EnterResponse>.Return(this);
        }
        public uint OpCode() { return OuterOpcode.G2C_EnterResponse; } 
        [ProtoMember(1)]
        public uint ErrorCode { get; set; }
    }
    /// <summary>
    /// 通知客户端账号重复登录
    /// </summary>
    [Serializable]
    [ProtoContract]
    public partial class C2G_RepeatLogin : AMessage, IMessage
    {
        public static C2G_RepeatLogin Create(bool autoReturn = true)
        {
            var c2G_RepeatLogin = MessageObjectPool<C2G_RepeatLogin>.Rent();
            c2G_RepeatLogin.AutoReturn = autoReturn;
            
            if (!autoReturn)
            {
                c2G_RepeatLogin.SetIsPool(false);
            }
            
            return c2G_RepeatLogin;
        }
        
        public void Return()
        {
            if (!AutoReturn)
            {
                SetIsPool(true);
                AutoReturn = true;
            }
            else if (!IsPool())
            {
                return;
            }
            Dispose();
        }

        public void Dispose()
        {
            if (!IsPool()) return; 
            MessageObjectPool<C2G_RepeatLogin>.Return(this);
        }
        public uint OpCode() { return OuterOpcode.C2G_RepeatLogin; } 
    }
    /// <summary>
    /// 角色信息
    /// </summary>
    [Serializable]
    [ProtoContract]
    public partial class RoleInfo : AMessage, IDisposable
    {
        public static RoleInfo Create(bool autoReturn = true)
        {
            var roleInfo = MessageObjectPool<RoleInfo>.Rent();
            roleInfo.AutoReturn = autoReturn;
            
            if (!autoReturn)
            {
                roleInfo.SetIsPool(false);
            }
            
            return roleInfo;
        }
        
        public void Return()
        {
            if (!AutoReturn)
            {
                SetIsPool(true);
                AutoReturn = true;
            }
            else if (!IsPool())
            {
                return;
            }
            Dispose();
        }

        public void Dispose()
        {
            if (!IsPool()) return; 
            RoleId = default;
            RoleConfigId = default;
            Name = default;
            Sex = default;
            Level = default;
            MessageObjectPool<RoleInfo>.Return(this);
        }
        /// <summary>
        /// RoleId
        /// </summary>
        [ProtoMember(1)]
        public long RoleId { get; set; }
        /// <summary>
        /// 对应的RoleConfigId
        /// </summary>
        [ProtoMember(2)]
        public int RoleConfigId { get; set; }
        /// <summary>
        /// 角色名字
        /// </summary>
        [ProtoMember(3)]
        public string Name { get; set; }
        /// <summary>
        /// 角色性别
        /// </summary>
        [ProtoMember(4)]
        public int Sex { get; set; }
        /// <summary>
        /// 角色等级
        /// </summary>
        [ProtoMember(5)]
        public int Level { get; set; }
    }
    /// <summary>
    /// 获取当前账号下的所有角色
    /// </summary>
    [Serializable]
    [ProtoContract]
    public partial class C2G_GetRoleListRequest : AMessage, IRequest
    {
        public static C2G_GetRoleListRequest Create(bool autoReturn = true)
        {
            var c2G_GetRoleListRequest = MessageObjectPool<C2G_GetRoleListRequest>.Rent();
            c2G_GetRoleListRequest.AutoReturn = autoReturn;
            
            if (!autoReturn)
            {
                c2G_GetRoleListRequest.SetIsPool(false);
            }
            
            return c2G_GetRoleListRequest;
        }
        
        public void Return()
        {
            if (!AutoReturn)
            {
                SetIsPool(true);
                AutoReturn = true;
            }
            else if (!IsPool())
            {
                return;
            }
            Dispose();
        }

        public void Dispose()
        {
            if (!IsPool()) return; 
            MessageObjectPool<C2G_GetRoleListRequest>.Return(this);
        }
        public uint OpCode() { return OuterOpcode.C2G_GetRoleListRequest; } 
        [ProtoIgnore]
        public G2C_GetRoleListResponse ResponseType { get; set; }
    }
    [Serializable]
    [ProtoContract]
    public partial class G2C_GetRoleListResponse : AMessage, IResponse
    {
        public static G2C_GetRoleListResponse Create(bool autoReturn = true)
        {
            var g2C_GetRoleListResponse = MessageObjectPool<G2C_GetRoleListResponse>.Rent();
            g2C_GetRoleListResponse.AutoReturn = autoReturn;
            
            if (!autoReturn)
            {
                g2C_GetRoleListResponse.SetIsPool(false);
            }
            
            return g2C_GetRoleListResponse;
        }
        
        public void Return()
        {
            if (!AutoReturn)
            {
                SetIsPool(true);
                AutoReturn = true;
            }
            else if (!IsPool())
            {
                return;
            }
            Dispose();
        }

        public void Dispose()
        {
            if (!IsPool()) return; 
            ErrorCode = 0;
            List = null;
            MessageObjectPool<G2C_GetRoleListResponse>.Return(this);
        }
        public uint OpCode() { return OuterOpcode.G2C_GetRoleListResponse; } 
        [ProtoMember(1)]
        public uint ErrorCode { get; set; }
        /// <summary>
        /// 角色列表
        /// </summary>
        [ProtoMember(2)]
        public List<RoleInfo> List { get; set; }
    }
    /// <summary>
    /// 创建一个角色
    /// </summary>
    [Serializable]
    [ProtoContract]
    public partial class C2G_CreateRoleRequest : AMessage, IRequest
    {
        public static C2G_CreateRoleRequest Create(bool autoReturn = true)
        {
            var c2G_CreateRoleRequest = MessageObjectPool<C2G_CreateRoleRequest>.Rent();
            c2G_CreateRoleRequest.AutoReturn = autoReturn;
            
            if (!autoReturn)
            {
                c2G_CreateRoleRequest.SetIsPool(false);
            }
            
            return c2G_CreateRoleRequest;
        }
        
        public void Return()
        {
            if (!AutoReturn)
            {
                SetIsPool(true);
                AutoReturn = true;
            }
            else if (!IsPool())
            {
                return;
            }
            Dispose();
        }

        public void Dispose()
        {
            if (!IsPool()) return; 
            Name = default;
            Sex = default;
            RoleConfigId = default;
            MessageObjectPool<C2G_CreateRoleRequest>.Return(this);
        }
        public uint OpCode() { return OuterOpcode.C2G_CreateRoleRequest; } 
        [ProtoIgnore]
        public G2C_CreateRoleResponse ResponseType { get; set; }
        [ProtoMember(1)]
        public string Name { get; set; }
        [ProtoMember(2)]
        public int Sex { get; set; }
        [ProtoMember(3)]
        public int RoleConfigId { get; set; }
    }
    [Serializable]
    [ProtoContract]
    public partial class G2C_CreateRoleResponse : AMessage, IResponse
    {
        public static G2C_CreateRoleResponse Create(bool autoReturn = true)
        {
            var g2C_CreateRoleResponse = MessageObjectPool<G2C_CreateRoleResponse>.Rent();
            g2C_CreateRoleResponse.AutoReturn = autoReturn;
            
            if (!autoReturn)
            {
                g2C_CreateRoleResponse.SetIsPool(false);
            }
            
            return g2C_CreateRoleResponse;
        }
        
        public void Return()
        {
            if (!AutoReturn)
            {
                SetIsPool(true);
                AutoReturn = true;
            }
            else if (!IsPool())
            {
                return;
            }
            Dispose();
        }

        public void Dispose()
        {
            if (!IsPool()) return; 
            ErrorCode = 0;
            MessageObjectPool<G2C_CreateRoleResponse>.Return(this);
        }
        public uint OpCode() { return OuterOpcode.G2C_CreateRoleResponse; } 
        [ProtoMember(1)]
        public uint ErrorCode { get; set; }
    }
    /// <summary>
    /// 删除角色
    /// </summary>
    [Serializable]
    [ProtoContract]
    public partial class C2G_RemoveRoleRequest : AMessage, IRequest
    {
        public static C2G_RemoveRoleRequest Create(bool autoReturn = true)
        {
            var c2G_RemoveRoleRequest = MessageObjectPool<C2G_RemoveRoleRequest>.Rent();
            c2G_RemoveRoleRequest.AutoReturn = autoReturn;
            
            if (!autoReturn)
            {
                c2G_RemoveRoleRequest.SetIsPool(false);
            }
            
            return c2G_RemoveRoleRequest;
        }
        
        public void Return()
        {
            if (!AutoReturn)
            {
                SetIsPool(true);
                AutoReturn = true;
            }
            else if (!IsPool())
            {
                return;
            }
            Dispose();
        }

        public void Dispose()
        {
            if (!IsPool()) return; 
            RoleId = default;
            MessageObjectPool<C2G_RemoveRoleRequest>.Return(this);
        }
        public uint OpCode() { return OuterOpcode.C2G_RemoveRoleRequest; } 
        [ProtoIgnore]
        public G2C_RemoveRoleResponse ResponseType { get; set; }
        [ProtoMember(1)]
        public long RoleId { get; set; }
    }
    [Serializable]
    [ProtoContract]
    public partial class G2C_RemoveRoleResponse : AMessage, IResponse
    {
        public static G2C_RemoveRoleResponse Create(bool autoReturn = true)
        {
            var g2C_RemoveRoleResponse = MessageObjectPool<G2C_RemoveRoleResponse>.Rent();
            g2C_RemoveRoleResponse.AutoReturn = autoReturn;
            
            if (!autoReturn)
            {
                g2C_RemoveRoleResponse.SetIsPool(false);
            }
            
            return g2C_RemoveRoleResponse;
        }
        
        public void Return()
        {
            if (!AutoReturn)
            {
                SetIsPool(true);
                AutoReturn = true;
            }
            else if (!IsPool())
            {
                return;
            }
            Dispose();
        }

        public void Dispose()
        {
            if (!IsPool()) return; 
            ErrorCode = 0;
            MessageObjectPool<G2C_RemoveRoleResponse>.Return(this);
        }
        public uint OpCode() { return OuterOpcode.G2C_RemoveRoleResponse; } 
        [ProtoMember(1)]
        public uint ErrorCode { get; set; }
    }
}