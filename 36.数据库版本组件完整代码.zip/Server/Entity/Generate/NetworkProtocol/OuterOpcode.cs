// ReSharper disable InconsistentNaming
namespace Fantasy
{
    /// <summary>
    /// 本代码有编辑器生成,请不要再这里进行编辑。
    /// </summary>
    public static partial class OuterOpcode
    {
        public const uint C2A_RegisterAccountRequest = 268445457;
        public const uint A2C_RegisterAccountResponse = 402663185;
        public const uint C2A_LoginAccountRequest = 268445458;
        public const uint A2C_LoginAccountResponse = 402663186;
        public const uint C2A_AddRecentServerRequest = 268445459;
        public const uint A2C_AddRecentServerResponse = 402663187;
        public const uint C2G_EnterRequest = 268445460;
        public const uint G2C_EnterResponse = 402663188;
        public const uint C2G_RepeatLogin = 134227729;
        public const uint C2G_GetRoleListRequest = 268445461;
        public const uint G2C_GetRoleListResponse = 402663189;
        public const uint C2G_CreateRoleRequest = 268445462;
        public const uint G2C_CreateRoleResponse = 402663190;
        public const uint C2G_RemoveRoleRequest = 268445463;
        public const uint G2C_RemoveRoleResponse = 402663191;
    }
}