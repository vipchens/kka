using System.Runtime.Loader;
using Fantasy.Helper;

namespace Fantasy;

public static class AssemblyHelper
{
    private static AssemblyLoadContext? _loadContext;
    
    /// <summary>
    /// 初始化程序集
    /// </summary>
    public static void Initialize()
    {
        LoadEntityAssembly();
        LoadHotfixAssembly();
    }
    
    /// <summary>
    /// 加载 Entity 的程序集
    /// </summary>
    private static void LoadEntityAssembly()
    {
        typeof(AssemblyHelper).Assembly.EnsureLoaded();
    }

    /// <summary>
    /// 加载/替换 Hotfix 的程序集
    /// </summary>
    public static void LoadHotfixAssembly()
    {
        if (_loadContext != null)
        {
            _loadContext.Unload();
            System.GC.Collect();
        }
        
        // 创建新的程序集加载
        _loadContext = new AssemblyLoadContext("HotfixAssembly");
        // 从本地文件中加载 DLL相关的数据
        var dllBytes = File.ReadAllBytes(Path.Combine(AppContext.BaseDirectory, "Hotfix.dll"));
        var pdbBytes = File.ReadAllBytes(Path.Combine(AppContext.BaseDirectory, "Hotfix.pdb"));
        // 从内存流中加载程序集
        var assembly = _loadContext.LoadFromStream(new MemoryStream(dllBytes),new MemoryStream(pdbBytes));
        // 强制触发注册框架的逻辑
        assembly.EnsureLoaded();
    }
}