using Fantasy.Entitas;
using MongoDB.Bson.Serialization.Attributes;

namespace Fantasy;

/// <summary>
/// 数据库管理组件
/// 负责场景启动时劝不动数据库版本迁移（如:创建索引等）。
/// </summary>
public sealed class DatabaseComponent : Entity
{
    /// <summary>
    /// 当前数据库版本记录。
    /// 避免后续重复查询数据库，此字段不持久化到数据库。
    /// </summary>
    [BsonIgnore]
    public DbVersion DbVersion;
}