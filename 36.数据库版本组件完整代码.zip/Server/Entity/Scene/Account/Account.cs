namespace Fantasy;

public sealed class Account : Entitas.Entity
{
    /// <summary>
    /// 账号名
    /// </summary>
    public string Name;
    /// <summary>
    /// 账号密码（MD5的方式存储)
    /// </summary>
    public string Password;  
    /// <summary>
    /// 账号创建时间
    /// </summary>
    public long CreateTime;
    /// <summary>
    /// 上次登录的时间
    /// </summary>
    public long LastLoginTime;
    /// <summary>
    /// 最近选择的服务器列表
    /// </summary>
    public List<int> RecentServers = new List<int>();
}