namespace Fantasy;

public struct AccountLoginResult
{
    public long AccountId;
    public string ToKen;
    public ErrorCode ErrorCode;
    public IReadOnlyList<int> RecentServer;

    public AccountLoginResult(ErrorCode errorCode)
    {
        ErrorCode = errorCode;
    }

    public AccountLoginResult(ErrorCode errorCode, string toKen, long accountId, IReadOnlyList<int> recentServer)
    {
        ToKen = toKen;
        AccountId = accountId;
        ErrorCode = errorCode;
        RecentServer = recentServer;
    }
}

public sealed class AccountManageComponent : Entitas.Entity
{
    
}