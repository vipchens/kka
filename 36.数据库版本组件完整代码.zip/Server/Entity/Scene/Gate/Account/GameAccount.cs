using Fantasy.Entitas;
using Fantasy.Network;
using MongoDB.Bson.Serialization.Attributes;

namespace Fantasy;

public sealed class GameAccount : Entity
{
    [BsonIgnore]
    public long SessionRuntimeId;
}