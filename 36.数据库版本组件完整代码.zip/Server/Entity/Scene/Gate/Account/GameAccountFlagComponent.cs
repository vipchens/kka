using Fantasy.Entitas;

namespace Fantasy;

public sealed class GameAccountFlagComponent : Entity
{
    // 有一种课程，当Account在其他地方被销毁了。
    // 这时候因为这个Account是会回收到池子中，所以这个引用还是有效的，但不是正确的。
    // 那这时候就会出现这个引用的Account可能是其他的用户的了。
    public EntityReference<GameAccount> GameAccount;
}