using Fantasy.Entitas;

namespace Fantasy;

public sealed class Role : Entity
{
    public int RoleConfigId;
    
    public string Name;
    public int Sex;
    public int Level;
    public long GameAccountId;
    
    public Table.RoleConfig RoleConfig => Config.RoleTable.Get(RoleConfigId);
}