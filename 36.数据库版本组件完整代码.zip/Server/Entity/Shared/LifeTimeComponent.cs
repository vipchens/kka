using Fantasy.Entitas;
// ReSharper disable ConditionIsAlwaysTrueOrFalseAccordingToNullableAPIContract

namespace Fantasy;

/// <summary>
/// 生命周期组件，挂在到实体后可设定一个延迟时间，到期后呢自动销毁父实体。
/// </summary>
public sealed class LifeTimeComponent : Entity
{
    /// <summary>
    /// 当前定时器任务的Id, 为 0 表示没有正在运行的任务定义器。
    /// </summary>
    public long TimerId;

    /// <summary>
    /// 销毁组件时取消未触发的定时器，防止回调在组件销毁后仍然运行。
    /// </summary>
    public override void Dispose()
    {
        if (IsDisposed)
        {
            return;
        }

        if (TimerId != 0)
        {
            // 取消尚未触发的定时器，ref 重载会自动的将TimerId设置为0.
            Scene.TimerComponent.Net.Remove(ref TimerId);
        }
        
        base.Dispose();
    }

    /// <summary>
    /// 设置父实体的存活时长，到期后会自动调用父实体的Dispose方法销毁父实体。
    /// 若有定时器在运行，会先取消旧的定时器在重新计时。
    /// </summary>
    /// <param name="milliseconds">延迟的时长，单位:毫秒</param>
    public void SetLifeTime(long milliseconds)
    {
        if (TimerId != 0)
        {
            // 若有定时器，先取消旧的在重新设置。
            Scene.TimerComponent.Net.Remove(ref TimerId);
        }
        
        if(Parent == null || Parent.IsDisposed)
        {
            Log.Warning($"{GetType().Name} SetLifeTime failed : Parent is null or disposed.");
            return;
        }

        // 使用EntityReference持有父亲的弱引用，避免父实体提前销毁后回调范围到无效的对象。
        EntityReference<Entity> entityReference = Parent;
        
        Scene.TimerComponent.Net.OnceTimer(milliseconds, () =>
        {
            // 转换：若父实体已被销毁，RuntimeId 就是不一样的，会返回为null.
            Entity entity = entityReference;

            TimerId = 0;
            
            if (entity != null)
            {
                Parent.Dispose();
            }
        });
    }
}