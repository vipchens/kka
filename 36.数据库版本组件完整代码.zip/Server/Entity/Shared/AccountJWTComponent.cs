using Fantasy.Entitas;
using Microsoft.IdentityModel.Tokens;

namespace Fantasy;

public sealed class AccountJWTComponent : Entity
{
    public SigningCredentials SigningCredentials;
    public TokenValidationParameters TokenValidationParameters;
}