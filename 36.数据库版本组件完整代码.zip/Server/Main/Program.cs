﻿
using Fantasy;
using Luban;

try
{
    // 初始化配置表
    Fantasy.Config.Initialize(file => new ByteBuf(File.ReadAllBytes("../../../../../Config/Binary/" + file + ".bytes")));
    // 强制加载程序集
    AssemblyHelper.Initialize();
    // 配置 NLog 日志
    var logger = new Fantasy.NLog("Server");
    // 启动 Fantasy 框架
    await Fantasy.Platform.Net.Entry.Start(logger);
}
catch (Exception ex)
{
    Console.WriteLine($"服务器初始化的时候发生了致命的错误:{ex.Message}");
    Environment.Exit(1);
}
