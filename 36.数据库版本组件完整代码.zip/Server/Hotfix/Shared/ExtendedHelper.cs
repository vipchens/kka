using Fantasy.Async;
using Fantasy.Entitas;
// ReSharper disable ConditionIsAlwaysTrueOrFalseAccordingToNullableAPIContract

namespace Fantasy.Hotfix;

/// <summary>
/// 扩展方法静态类
/// </summary>
public static class ExtendedHelper
{
    /// <summary>
    /// 设置父实体的存活时长，到期后会自动调用父实体的Dispose方法销毁父实体。
    /// 若有定时器在运行，会先取消旧的定时器在重新计时。
    /// </summary>
    /// <param name="self"></param>
    /// <param name="milliseconds">延迟的时长，单位:毫秒</param>
    public static void SetLifeTime(this Entity self, long milliseconds)
    {
        var lifeTimeComponent = self.GetComponent<LifeTimeComponent>() ?? self.AddComponent<LifeTimeComponent>();
        lifeTimeComponent.SetLifeTime(milliseconds);
    }
    
    /// <summary>
    /// 设置父实体的延迟销毁定时器。
    /// 若已存在定时器，会先取消旧的再重新注册，实现"刷新超时"效果。
    /// </summary>
    /// <param name="self">父实体</param>
    /// <param name="timeout">超时时间（毫秒），默认 3000ms</param>
    /// <param name="task">超时触发后、销毁父实体前执行的可选异步任务</param>
    public static void SetDestroyTimeout(this Entity self, int timeout = 3000, Func<FTask>? task = null)
    {
        var entityTimeoutComponent = self.GetComponent<EntityTimeoutComponent>() ?? self.AddComponent<EntityTimeoutComponent>();
        entityTimeoutComponent.SetDestroyTimeout(timeout, task);
    }
    
    /// <summary>
    /// 取消当前的延迟销毁定时器。
    /// </summary>
    public static void CancelDestroyTimeout(this Entity self)
    {
        self.GetComponent<EntityTimeoutComponent>()?.CancelDestroyTimeout();
    }
}