using System.IdentityModel.Tokens.Jwt;
using System.Security.Cryptography;
using Fantasy.Entitas.Interface;
using Microsoft.IdentityModel.Tokens;
#pragma warning disable CS8625 // Cannot convert null literal to non-nullable reference type.

namespace Fantasy.Hotfix;

/// <summary>
/// AccountJWTComponent 的 Awake 生命周期熊，负责组件初始化。
/// </summary>
public sealed class AccountJWTComponentAwakeSystem : AwakeSystem<AccountJWTComponent>
{
    protected override void Awake(AccountJWTComponent self)
    {
        self.Awake();
    }
}

public sealed class AccountJWTComponentDestroySystem : DestroySystem<AccountJWTComponent>
{
    protected override void Destroy(AccountJWTComponent self)
    {
        self.SigningCredentials = null;
        self.TokenValidationParameters = null;
    }
}

public static class AccountJWTHelper
{
    public static void Awake(this AccountJWTComponent self)
    {
        var rsa = RSA.Create();
        rsa.ImportRSAPublicKey( Convert.FromBase64String(Config.Setting.AccountTokenPublicKeyPem), out _);
        rsa.ImportRSAPrivateKey( Convert.FromBase64String( Config.Setting.AccountTokenPrivateKeyPem), out _);
        self.SigningCredentials = new SigningCredentials(new RsaSecurityKey(rsa), SecurityAlgorithms.RsaSha256);
        self.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateLifetime = true, // 验证令牌是否过期
            ClockSkew = TimeSpan.Zero, // 取消默认5分钟始终偏差容忍，严格按过期时间验证
            ValidateIssuer = true, // 验证发证者
            ValidateAudience = true, // 验证受众  
            ValidateIssuerSigningKey = true, // 验证签名密钥
            ValidIssuer = "Fantasy", // 有效的发证者
            ValidAudience = "Fantasy", // 有效的受众
            IssuerSigningKey = new RsaSecurityKey(rsa), // RSA 公钥做为签名验证的密钥
        };
    }

    /// <summary>
    /// 生成包含账号信息的JWT Token
    /// 直接构造JwtHeader + JwtPayload ，里面携带了accountId和accountName
    /// </summary>
    /// <param name="scene"></param>
    /// <param name="accountId">账号ID</param>
    /// <param name="accountName">账号名称</param>
    /// <returns>签名后的JWT Token 字符串</returns>
    public static string CreateToKen(Scene scene, long accountId, string accountName)
    {
        return scene.GetComponent<AccountJWTComponent>().CreateToKen(accountId, accountName);
    }

    /// <summary>
    /// 验证JWT ToKen 的合法性，包括签名、发证者、受众及过期时间。
    /// </summary>
    /// <param name="scene"></param>
    /// <param name="toKen">待验证的 JWT ToKen 字符串</param>
    /// <param name="accountId">验证成功时输出的账号Id,失败时为0.</param>
    /// <param name="accountName">验证成功时输出的账号名称，失败是为null。</param>
    /// <returns>验证成功返回 true，否则返回 false</returns>
    public static bool ValidationToKen(Scene scene, string toKen, out long accountId, out string accountName)
    {
        return scene.GetComponent<AccountJWTComponent>().ValidationToKen(toKen, out accountId, out accountName);
    }

    /// <summary>
    /// 生成包含账号信息的JWT Token
    /// 直接构造JwtHeader + JwtPayload ，里面携带了accountId和accountName
    /// </summary>
    /// <param name="self"></param>
    /// <param name="accountId">账号ID</param>
    /// <param name="accountName">账号名称</param>
    /// <returns>签名后的JWT Token 字符串</returns>
    private static string CreateToKen(this AccountJWTComponent self, long accountId, string accountName)
    {
        var now  = DateTime.UtcNow;

        var jwtPayload = new JwtPayload
        {
            ["iss"] = "Fantasy",        // 发行者
            ["aud"] = "Fantasy",        // 受众
            ["nbf"] = EpochTime.GetIntDate(now),    // 生效时间
            ["exp"] = EpochTime.GetIntDate(now.AddMilliseconds(Config.Setting.AccountTokenExpires)), // 过期时间
            ["aId"] = accountId,
            ["aName"] = accountName,
        };

        var jwtSecurityToken = new JwtSecurityToken(new JwtHeader(self.SigningCredentials), jwtPayload);
        return new JwtSecurityTokenHandler().WriteToken(jwtSecurityToken);
    }

    /// <summary>
    /// 验证JWT ToKen 的合法性，包括签名、发证者、受众及过期时间。
    /// 任何验证失败均返回 false/。
    /// </summary>
    /// <param name="self"></param>
    /// <param name="toKen">待验证的 JWT ToKen 字符串</param>
    /// <param name="accountId">验证成功时输出的账号Id,失败时为0.</param>
    /// <param name="accountName">验证成功时输出的账号名称，失败是为null。</param>
    /// <returns>验证成功返回 true，否则返回 false</returns>
    private static bool ValidationToKen(this AccountJWTComponent self,string toKen, out long accountId, out string accountName)
    {
        accountId = 0;
        accountName = null;

        try
        {
            var claimsPrincipal = new JwtSecurityTokenHandler().ValidateToken(
                toKen,
                self.TokenValidationParameters, out _
            );

            var accountIdClaim = claimsPrincipal.FindFirst("aId");
            var accountNameClaim = claimsPrincipal.FindFirst("aName");

            if (accountIdClaim == null || accountNameClaim == null)
            {
                return false;
            }
            
            accountId = long.Parse(accountIdClaim.Value);
            accountName = accountNameClaim.Value;
            return true;
        }
        catch (Exception e)
        {
            return false;
        }
    }
}