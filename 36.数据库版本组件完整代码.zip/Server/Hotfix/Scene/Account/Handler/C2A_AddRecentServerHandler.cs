using Fantasy.Async;
using Fantasy.Network;
using Fantasy.Network.Interface;

namespace Fantasy.Hotfix;

public sealed class C2A_AddRecentServerHandler : MessageRPC<C2A_AddRecentServerRequest,A2C_AddRecentServerResponse>
{
    protected override async FTask Run(Session session, C2A_AddRecentServerRequest request, A2C_AddRecentServerResponse response, Action reply)
    {
        await AccountHelper.AddRecentServer(session.Scene, request.AccountId, request.ServerConfigId);
    }
}