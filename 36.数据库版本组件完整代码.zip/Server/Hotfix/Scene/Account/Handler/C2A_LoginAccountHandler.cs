using Fantasy.Async;
using Fantasy.Network;
using Fantasy.Network.Interface;

namespace Fantasy.Hotfix;

public sealed class C2A_LoginAccountHandler : MessageRPC<C2A_LoginAccountRequest, A2C_LoginAccountResponse>
{
    protected override async FTask Run(Session session, C2A_LoginAccountRequest request, A2C_LoginAccountResponse response, Action reply)
    {
        var result = await AccountHelper.Login(session.Scene, request.Account, request.Password);

        if (result.ErrorCode == ErrorCode.Success)
        {
            response.AccountId = result.AccountId;
            response.Token = result.ToKen;
            response.List = Config.ServerTable.GetServerList();

            if (result.RecentServer.Count > 0)
            {
                response.RecentServers.AddRange(result.RecentServer);
            }
        }
        else
        {
            response.ErrorCode = (uint)result.ErrorCode;
        }
        
        session.SetLifeTime(2000);
    }
}