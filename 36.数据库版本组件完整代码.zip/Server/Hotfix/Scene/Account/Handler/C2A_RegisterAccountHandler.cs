using Fantasy.Async;
using Fantasy.Network;
using Fantasy.Network.Interface;

namespace Fantasy.Hotfix;

public class C2A_RegisterAccountHandler : MessageRPC<C2A_RegisterAccountRequest, A2C_RegisterAccountResponse>
{
    protected override async FTask Run(Session session, C2A_RegisterAccountRequest request, A2C_RegisterAccountResponse response, Action reply)
    {
        response.ErrorCode = (uint)await AccountHelper.Register(session.Scene, request.Account, request.Password);
        session.SetLifeTime(2000);
    }
}