using Fantasy.Entitas.Interface;
#pragma warning disable CS8625 // Cannot convert null literal to non-nullable reference type.

namespace Fantasy.Hotfix;

public sealed class AccountDestroySystem : DestroySystem<Account>
{
    protected override void Destroy(Account self)
    {
        self.Name = null;
        self.Password = null;
        self.CreateTime = 0;
        self.LastLoginTime = 0;
        self.RecentServers.Clear();
    }
}