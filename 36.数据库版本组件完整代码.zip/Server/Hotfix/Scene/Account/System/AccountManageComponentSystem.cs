using System.Security.Cryptography;
using System.Text;
using Fantasy.Async;
using Fantasy.Entitas;
using Fantasy.Helper;
// ReSharper disable ConditionIsAlwaysTrueOrFalseAccordingToNullableAPIContract

namespace Fantasy.Hotfix;

public static class AccountHelper
{
    /// <summary>
    /// 注册新的账号
    /// </summary>
    /// <param name="scene">当前Scene</param>
    /// <param name="name">账号名，不能为空</param>
    /// <param name="password">密码，不能为空</param>
    /// <returns>ErrorCode.Success 表示成功，其他值表示失败原因。</returns>
    public static FTask<ErrorCode> Register(Scene scene, string name, string password)
    {
        return scene.GetComponent<AccountManageComponent>().Register(name, password);
    }

    /// <summary>
    /// 登录账号
    /// </summary>
    /// <param name="scene"></param>
    /// <param name="name">用户名</param>
    /// <param name="password">密码</param>
    /// <returns></returns>
    public static FTask<AccountLoginResult> Login(Scene scene, string name, string password)
    {
        return scene.GetComponent<AccountManageComponent>().Login(name, password);
    }

    /// <summary>
    /// 添加最新的服务器
    /// </summary>
    /// <param name="scene"></param>
    /// <param name="accountId">账号ID</param>
    /// <param name="serverConfigId">服务器配置ID</param>
    /// <returns></returns>
    public static FTask AddRecentServer(Scene scene, long accountId, int serverConfigId)
    {
        return scene.GetComponent<AccountManageComponent>().AddRecentServer(accountId, serverConfigId);
    }
    
    /// <summary>
    /// 注册账号的具体实现，通过协程锁保证同一个账号名不会并发注册，也可以理解是不会进行数据穿透或击穿
    /// </summary>
    /// <param name="self"></param>
    /// <param name="name"></param>
    /// <param name="password"></param>
    /// <returns></returns>
    private static async FTask<ErrorCode> Register(this AccountManageComponent self, string name, string password)
    {
        if (string.IsNullOrWhiteSpace(name) || string.IsNullOrWhiteSpace(password))
        {
            return ErrorCode.Register_InvalidParameter;   // 账号或密码不能为空。
        }
        
        // 这里要自己实现一下复杂的用户名和密码的效验逻辑
        // 比如。名字不能超过多少个字符，不能包含特殊符号，或者不能是中文等等。
        // 密码不能太简单，比如最低要求8位，或密码要求有大小写甚至特殊符号。

        try
        {
            // 如果上线的效验全部通过了，那就要数据库中查询是否存在该账号了

            var scene = self.Scene;
            var worldDatabase = scene.World.Database;
            var waitForId = HashCodeHelper.ComputeHash64(name);

            using (await scene.CoroutineLockComponent.Wait(CoroutineLockType.AccountRegisterLock, waitForId,"AccountHelper.Register",10000))
            {
                if (await worldDatabase.Exist<Account>(d => d.Name == name))
                {
                    return ErrorCode.Register_AccountIsExists;   //账号已存在的错误码
                }
                
                // 将密码转换为MD5哈希后存储
                var md5 = MD5.HashData(Encoding.UTF8.GetBytes(password));
                var hashPassword = Convert.ToHexString(md5).ToLower();

                // 创建新账号并持久化到数据库
                using (var account = Entity.Create<Account>(scene, true, true))
                {
                    account.Name = name;
                    account.Password = hashPassword;
                    account.CreateTime = TimeHelper.Now;
                    await worldDatabase.Insert(account);
                }
        
                return ErrorCode.Success;
            }
        }
        catch (Exception e)
        {
            Log.Error(e);
            return ErrorCode.Register_UnknownError;   // 执行注册的是否发生的未知错误。
        }
    }

    /// <summary>
    /// 登录账号
    /// </summary>
    /// <param name="self"></param>
    /// <param name="name">用户名</param>
    /// <param name="password">密码</param>
    /// <returns></returns>
    private static async FTask<AccountLoginResult> Login(this AccountManageComponent self, string name, string password)
    {
        if (string.IsNullOrWhiteSpace(name) || string.IsNullOrWhiteSpace(password))
        {
            return new AccountLoginResult(ErrorCode.Login_InvalidParameter);
        }

        try
        {
            var scene = self.Scene;
            var worldDatabase = scene.World.Database;

            // 利用缓存来提高命中，减少数据库的消耗，缺点:内存会变大 用字典来缓存登录数据，
            // 从数据库查询账号
            var account = await worldDatabase.First<Account>(d => d.Name == name);

            if (account == null)
            {
                return new AccountLoginResult(ErrorCode.Login_AccountNotExist);
            }

            // 密码哈希计算（和注册的完全一致）
            var md5 = MD5.HashData(Encoding.UTF8.GetBytes(password));
            var hashPassword = Convert.ToHexString(md5).ToLower();
            // 密码验证
            if (account.Password != hashPassword)
            {
                return new AccountLoginResult(ErrorCode.Login_AccountExists_PasswordError);
            }

            // 更新最后登录的时间
            account.LastLoginTime = TimeHelper.Now;
            // 更新数据到数据库中
            await worldDatabase.Save(account);
            // 生成 ToKen 供后续游戏服务器登录使用
            var token = AccountJWTHelper.CreateToKen(scene, account.Id, account.Name);
            return new AccountLoginResult(ErrorCode.Success, token, account.Id, account.RecentServers);
        }
        catch (Exception e)
        {
            Log.Error(e);
            return new AccountLoginResult(ErrorCode.Login_UnknownError);
        }
    }

    /// <summary>
    /// 添加最新的服务器
    /// </summary>
    /// <param name="self"></param>
    /// <param name="accountId"></param>
    /// <param name="serverConfigId"></param>
    private static async FTask AddRecentServer(this AccountManageComponent self, long accountId, int serverConfigId)
    {
        if (accountId == 0 || serverConfigId == 0)
        {
            return;
        }

        if (!Config.ServerTable.IsExist(serverConfigId))
        {
            return;
        }

        var scene = self.Scene;
        var worldDatabase = scene.World.Database;

        var account = await worldDatabase.Query<Account>(accountId);

        if (account == null)
        {
            return;
        }

        var accountRecentServers = account.RecentServers;
        if (accountRecentServers.Count >= Config.Setting.RecentServerMax)
        {
            accountRecentServers.RemoveAt(accountRecentServers.Count - 1);
        }

        accountRecentServers.Remove(serverConfigId);
        accountRecentServers.Insert(0, serverConfigId);
        
        await worldDatabase.Save(account);
    }
}