using Fantasy.Async;
using Fantasy.Entitas;

namespace Fantasy.Hotfix;

public static class DatabaseComponentSystem
{
    private static readonly List<IDbMigration> DbMigrations =
    [
        new DbMigration_V1() // V1 账号和角色基础索引
    ];
    
    public static async FTask Migrate(this DatabaseComponent self)
    {
        var db = self.Scene.World.Database;

        // 读取当前版本记录，首次运行时集合是空的，则初始记录版本号是0，表示尚未执行任何迁移
        var dbVersion = await db.First<DbVersion>(d => d.Version >= 0);

        if (dbVersion == null)
        {
            dbVersion = Entity.Create<DbVersion>(self.Scene);
            dbVersion.Version = 0;
            await db.Insert(dbVersion);
        }
        
        // 讲版本记录缓存到组件上，避免后续重新查询
        self.DbVersion = dbVersion;
        var currentVersion = dbVersion.Version;

        // 筛选出尚未执行的迁移并按版本号升序排序
        var pending = DbMigrations
            .Where(d => d.Version > currentVersion)
            .OrderBy(d => d.Version)
            .ToList();

        if (pending.Count == 0)
        {
            Log.Debug($"[DatabaseComponent] 数据库已经是最新版本 （V{currentVersion}）。");
            return;
        }
        
        Log.Info($"[DatabaseComponent] 当前版本 V{currentVersion},待执行迁移 {pending.Count}个。");
        
        foreach (var dbMigration in pending)
        {
            Log.Info($"[DatabaseComponent] 开始执行迁移 V{dbMigration.Version}...");
            await dbMigration.Upgrade(db);
            // 每个迁移完成后立即持久化
            // 若在此之前服务器异常退出，下次重启会重跑迁移而不是跳过，保证不漏执行，
            dbVersion.Version = dbMigration.Version;
            await db.Save(dbVersion);
            Log.Info($"[DatabaseComponent] 迁移 V{dbMigration.Version} 执行完毕。");
        }
    }
}