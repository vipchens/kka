using Fantasy.Async;
using Fantasy.Database;
using MongoDB.Driver;

namespace Fantasy.Hotfix;

public sealed class DbMigration_V1 : IDbMigration
{
    /// <summary>
    /// 当前迁移版本号
    /// </summary>
    public int Version => 1;
    
    /// <summary>
    /// 执行迁移的逻辑
    /// </summary>
    /// <param name="db"></param>
    /// <returns></returns>
    /// <exception cref="NotImplementedException"></exception>
    public async FTask Upgrade(IDatabase db)
    {
        // Account.Name 升序唯一索引
        // 用途：注册和登录均通过 Name 字段查询，唯一约束防止重名注册，提升查询效率
        await db.CreateIndex<Account>(
            [Builders<Account>.IndexKeys.Ascending(d => d.Name)],
            [new CreateIndexOptions { Unique = true, Name = "idx_account_name" }]
        );
        // Role.Name 升序唯一索引
        // 用途：创建角色和查询均通过 Name 字段查询，唯一约束防止重名创建，提升查询效率
        await db.CreateIndex<Role>(
            [Builders<Role>.IndexKeys.Ascending(d => d.Name)],
            [new CreateIndexOptions { Unique = true, Name = "idx_role_name" }]
        );
    }
}