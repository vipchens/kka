using Fantasy.Async;
using Fantasy.Network;
using Fantasy.Network.Interface;
// ReSharper disable ConditionIsAlwaysTrueOrFalseAccordingToNullableAPIContract

namespace Fantasy.Hotfix;

public sealed class C2G_GetRoleListHandler : MessageRPC<C2G_GetRoleListRequest, G2C_GetRoleListResponse>
{
    protected override async FTask Run(Session session, C2G_GetRoleListRequest request, G2C_GetRoleListResponse response, Action reply)
    {
        var gameAccountFlagComponent = session.GetComponent<GameAccountFlagComponent>();

        if (gameAccountFlagComponent == null)
        {
            return;
        }

        GameAccount account = gameAccountFlagComponent.GameAccount;

        if (account == null)
        {
            response.ErrorCode = 1; // 没有找到账号信息的错误码
            return;
        }

        response.List = await RoleHelper.GetRoleInfos(session.Scene, account.Id);
    }
}