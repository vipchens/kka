using Fantasy.Async;
using Fantasy.Network;
using Fantasy.Network.Interface;
// ReSharper disable ConditionIsAlwaysTrueOrFalseAccordingToNullableAPIContract

namespace Fantasy.Hotfix;

public sealed class C2G_CreateRoleHandler : MessageRPC<C2G_CreateRoleRequest, G2C_CreateRoleResponse>
{
    protected override async FTask Run(Session session, C2G_CreateRoleRequest request, G2C_CreateRoleResponse response, Action reply)
    {
        var gameAccountFlagComponent = session.GetComponent<GameAccountFlagComponent>();

        if (gameAccountFlagComponent == null)
        {
            return;
        }

        GameAccount account = gameAccountFlagComponent.GameAccount;

        if (account == null)
        {
            response.ErrorCode = 1; // 没有找到账号信息的错误码
            return;
        }

        response.ErrorCode = (uint)await RoleHelper.CreateRole(account, request.Name, request.Sex, request.RoleConfigId);
    }
}