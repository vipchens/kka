using Fantasy.Async;
using Fantasy.Network;
using Fantasy.Network.Interface;
#pragma warning disable CS8625 // Cannot convert null literal to non-nullable reference type.

namespace Fantasy.Hotfix;

public sealed class C2G_EnterHandler : MessageRPC<C2G_EnterRequest, G2C_EnterResponse>
{
    protected override async FTask Run(Session session, C2G_EnterRequest request, G2C_EnterResponse response, Action reply)
    {
        if (string.IsNullOrWhiteSpace(request.ToKen))
        {
            // 1.客户端漏传了，大意了或者客户端逻辑出错了。
            // 2.恶意攻击导致的。
            session.Dispose();
            return;
        }
        
        var scene = session.Scene;

        if (!AccountJWTHelper.ValidationToKen(scene, request.ToKen, out var accountId, out var accountName))
        {
            // 如果失败，无论什么原因，毫不犹豫，直接断开当前会话。
            // 不一定是恶意攻击，也有可能是token设置问题。要自己查。
            session.Dispose();
            return;
        }

        var gameAccountManageComponent = scene.GetComponent<GameAccountManageComponent>();

        if (gameAccountManageComponent.TryGet(accountId, out var gameAccount))
        {
            // 如果有延迟下线的计划任务，那就先取消一下。
            gameAccount.CancelDestroyTimeout();
            // 如果存在的情况下，要进行顶号或者重登、断线重连的流程。
            // 如果再Gate的缓存中已经存在了该账号，那只能是以下几种可能:
            // 1.同一个客户端发送重复的登录请求。
            // 2.客户端经理的断线然后又重新连接到服务器上了。（断线重连）。
            // 3.多个客户端同时登录这个账号。（顶号）
            if (session.RuntimeId == gameAccount.SessionRuntimeId)
            {
                // 如果执行到这里，说明客户端发送了多次登录的请求，这样的情况下，直接返回就可以了。不需要做任何操作。
                return;
            }

            if (scene.TryGetEntity<Session>(gameAccount.SessionRuntimeId, out var oldSession))
            {
                // 如果这个Session再当前的框架中并且可以查询到。
                // 那表示当前的会话还是存在，那就有如下几种可能:
                // 1.客户端断线重连，要给这个Session发送一个消息，通知有人登录了。
                // 2.其他客户端登录了这个账号，要给这个Session发送一个消息，通知有人登录了。
                oldSession.GetComponent<GameAccountFlagComponent>().SetAccount(null);
                // 给旧的客户端发送一个重新登录的消息,如果当前客户端上是自己上次登录的，发送也收不到。
                oldSession.Send(new C2G_RepeatLogin());
                // 给上一个登录的Session一个延迟销毁的任务，因为不做这个延迟，有可能消息还没有发到就消息。
                oldSession.SetLifeTime(3000);
            }
        }
        else
        {
            // 缓存中没有存在该账号
            // 首先要先到数据库中查询是否存在这个账号
            // 如果没有，就要创建一个新的账号并且保存到数据库。
            gameAccount = await gameAccountManageComponent.LoadOrCreate(accountId);
            // 执行上线的操作。
            await gameAccount.Online();
        }
        
        // 给当前Session添加一个组件，当Session销毁的时候会附带销毁这个组件
        session.AddComponent<GameAccountFlagComponent>().SetAccount(gameAccount);
        // 关联下当前Session的RuntimeId.
        gameAccount.SessionRuntimeId = session.RuntimeId;
    }
}