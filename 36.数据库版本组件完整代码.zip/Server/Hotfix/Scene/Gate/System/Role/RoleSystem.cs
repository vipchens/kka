using Fantasy.Async;
using Fantasy.Entitas;
using Fantasy.Helper;
// ReSharper disable ConditionIsAlwaysTrueOrFalseAccordingToNullableAPIContract

namespace Fantasy.Hotfix;

public static class RoleHelper
{
    /// <summary>
    /// 创建角色
    /// </summary>
    /// <param name="gameAccount">游戏账号</param>
    /// <param name="roleName">角色名称</param>
    /// <param name="sex">性别（1=男，2=女）</param>
    /// <param name="roleConfigId">角色配置Id</param>
    /// <returns></returns>
    public static async FTask<ErrorCode> CreateRole(GameAccount gameAccount, string roleName, int sex, int roleConfigId)
    {
        // 效验角色名
        var nameError = ValidateRoleName(roleName);

        if (nameError != ErrorCode.Success)
        {
            return nameError;
        }

        // 效验性别
        if (sex < 1 || sex > 2)
        {
            return ErrorCode.Role_SexInvalid;
        }
        
        var scene = gameAccount.Scene;
        var roleInfo = Config.RoleTable.GetOrDefault(roleConfigId);

        // 效验角色配置是否存在
        if (roleInfo == null)
        {
            return ErrorCode.Role_ConfigNotFound;
        }

        var waitForId = HashCodeHelper.ComputeHash64(roleName);
        
        using (await scene.CoroutineLockComponent.Wait(CoroutineLockType.RoleCreateLock, waitForId, "RoleHelper.CreateRole"))
        {
            // 检查角色名是否存在
            if (await scene.World.Database.Exist<Role>(d => d.Name == roleName))
            {
                return ErrorCode.Role_NameDuplicate;
            }

            using (var role = Entity.Create<Role>(scene, true, true))
            {
                role.Name = roleName;
                role.Sex = sex;
                role.Level = roleInfo.Level;
                role.RoleConfigId = roleConfigId;
                role.GameAccountId = gameAccount.Id;
                // 保存角色到数据库
                await role.SaveDatabase();
            }
        }
        
        return ErrorCode.Success;
    }

    /// <summary>
    /// 删除角色
    /// </summary>
    /// <param name="gameAccount"></param>
    /// <param name="roleId">角色ID</param>
    /// <returns></returns>
    public static async FTask<ErrorCode> RemoveRole(GameAccount gameAccount, long roleId)
    {
        if (roleId == 0)
        {
            return ErrorCode.Role_NotFound;
        }

        var role = await gameAccount.Scene.World.Database.Query<Role>(roleId);

        if (role == null)
        {
            return ErrorCode.Role_NotFound;
        }

        // 效验角色是否属于当前账号
        if (role.GameAccountId != gameAccount.Id)
        {
            return ErrorCode.Role_NotBelongToAccount;
        }
        
        // 从数据库删除角色
        await gameAccount.Scene.World.Database.Remove<Role>(roleId);
        return ErrorCode.Success;
    }
    
    /// <summary>
    /// 获取账号下的所有角色信息
    /// </summary>
    /// <param name="scene"></param>
    /// <param name="gameAccountId">游戏账号ID</param>
    /// <returns></returns>
    public static async FTask<List<RoleInfo>> GetRoleInfos(Scene scene,long gameAccountId)
    {
        if (gameAccountId <= 0)
        {
            return new List<RoleInfo>();
        }

        var roles = await scene.World.Database.Query<Role>(d => d.GameAccountId == gameAccountId);
        var list = new List<RoleInfo>();

        if (roles.Count <= 0)
        {
            return list;
        }
        
        // 转换为角色信息列表
        list.AddRange(roles.Select(r=>r.ToRoleInfo()));
        return list;
    }

    /// <summary>
    /// 保存角色到数据库
    /// </summary>
    /// <param name="role"></param>
    public static async FTask SaveDatabase(this Role role)
    {
        await role.Scene.World.Database.Save(role);
    }

    /// <summary>
    /// 将角色实体转换到角色的网络协议信息
    /// </summary>
    /// <param name="role"></param>
    /// <returns>角色的网络协议信息</returns>
    public static RoleInfo ToRoleInfo(this Role role)
    {
        return new RoleInfo()
        {
            RoleId = role.Id,
            RoleConfigId = role.RoleConfigId,
            Name = role.Name,
            Level = role.Level,
            Sex = role.Sex
        };
    }
    
    /// <summary>
    /// 校验角色名是否合法。
    /// 规则：
    ///   1. 不能为空或纯空白。
    ///   2. 只允许汉字（\u4e00-\u9fa5）、英文字母（a-z / A-Z）、数字（0-9），其余字符一律拒绝。
    ///   3. 根据字符组成分为四种模式，各自套用独立的长度配置：
    ///      - 纯中文    ：汉字数在 [RoleNameChineseMinCount, RoleNameChineseMaxCount] 范围内
    ///      - 纯英文    ：字母数在 [RoleNameLatinMinLength,   RoleNameLatinMaxLength]  范围内
    ///      - 纯数字    ：数字数在 [RoleNameDigitMinLength,   RoleNameDigitMaxLength]  范围内
    ///      - 混排（任意两种及以上组合）
    ///                  ：UTF-8 字节数（汉字 3 字节，字母/数字各 1 字节）
    ///                    在 [RoleNameMixedMinBytes, RoleNameMixedMaxBytes] 范围内
    /// </summary>
    /// <param name="roleName">待校验的角色名</param>
    /// <returns>
    ///   Success              — 校验通过
    ///   Role_NameInvalid     — 名字为空或纯空白
    ///   Role_NameCharInvalid — 含非法字符
    ///   Role_NameLengthOutOfRange — 长度不在对应模式的配置范围内
    /// </returns>
    private static ErrorCode ValidateRoleName(string roleName)
    {
        // 1. 空值校验
        if (string.IsNullOrWhiteSpace(roleName))
        {
            return ErrorCode.Role_NameInvalid;
        }

        // 2. 单次遍历：同时完成字符合法性校验与三类字符计数
        var chineseCount = 0; // 汉字数
        var latinCount   = 0; // 英文字母数
        var digitCount   = 0; // 数字数
        foreach (var c in roleName)
        {
            if (c >= '\u4e00' && c <= '\u9fa5')
            {
                chineseCount++;
            }
            else if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z'))
            {
                latinCount++;
            }
            else if (c >= '0' && c <= '9')
            {
                digitCount++;
            }
            else
            {
                // 含非法字符，立即返回，无需继续遍历
                return ErrorCode.Role_NameCharInvalid;
            }
        }

        // 3. 统计活跃字符类型数，>= 2 即为混排
        var typeCount = (chineseCount > 0 ? 1 : 0)
                      + (latinCount   > 0 ? 1 : 0)
                      + (digitCount   > 0 ? 1 : 0);

        bool lengthValid;
        if (typeCount >= 2)
        {
            // 混排（英文+数字 / 中文+英文 / 中文+数字 / 三者皆有）
            // UTF-8 字节数：汉字 3 字节，字母/数字各 1 字节
            var byteLen = chineseCount * 3 + latinCount + digitCount;
            lengthValid = byteLen >= Config.Setting.RoleNameMixedMinBytes
                       && byteLen <= Config.Setting.RoleNameMixedMaxBytes;
        }
        else if (chineseCount > 0)
        {
            // 纯中文
            lengthValid = chineseCount >= Config.Setting.RoleNameChineseMinCount
                       && chineseCount <= Config.Setting.RoleNameChineseMaxCount;
        }
        else if (latinCount > 0)
        {
            // 纯英文
            lengthValid = latinCount >= Config.Setting.RoleNameLatinMinLength
                       && latinCount <= Config.Setting.RoleNameLatinMaxLength;
        }
        else
        {
            // 纯数字
            lengthValid = digitCount >= Config.Setting.RoleNameDigitMinLength
                       && digitCount <= Config.Setting.RoleNameDigitMaxLength;
        }

        return lengthValid ? ErrorCode.Success : ErrorCode.Role_NameLengthOutOfRange;
    }
}