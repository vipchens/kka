using Fantasy.Async;
using Fantasy.Entitas;
// ReSharper disable ConditionIsAlwaysTrueOrFalseAccordingToNullableAPIContract

#pragma warning disable CS8601 // Possible null reference assignment.
namespace Fantasy.Hotfix;

public static class GameAccountManageComponentSystem
{
    /// <summary>
    /// 将账号对象手动添加到管理器的缓存中
    /// </summary>
    /// <param name="self"></param>
    /// <param name="gameAccount"></param>
    public static void Add(this GameAccountManageComponent self, GameAccount gameAccount)
    {
        self.Accounts.Add(gameAccount.Id, gameAccount);
    }

    /// <summary>
    /// 从管理缓存中获取账号（不涉及数据库)
    /// </summary>
    /// <param name="self"></param>
    /// <param name="accountId"></param>
    /// <returns></returns>
    public static GameAccount? Get(this GameAccountManageComponent self, long accountId)
    {
        return self.Accounts.GetValueOrDefault(accountId);
    }

    /// <summary>
    /// 尝试从管理器缓存中获取账号。
    /// </summary>
    /// <param name="self"></param>
    /// <param name="accountId"></param>
    /// <param name="gameAccount"></param>
    /// <returns></returns>
    public static bool TryGet(this GameAccountManageComponent self, long accountId, out GameAccount gameAccount)
    {
        return self.Accounts.TryGetValue(accountId, out gameAccount);
    }

    /// <summary>
    /// 根据AccountId从管理器中移除账号
    /// </summary>
    /// <param name="self"></param>
    /// <param name="accountId">账号ID</param>
    /// <param name="isDispose">移除后是否销毁实体对象，默认为true</param>
    public static void Remove(this GameAccountManageComponent self, long accountId, bool isDispose = true)
    {
        if (!self.Accounts.Remove(accountId, out var gameAccount))
        {
            return;
        }

        if (!isDispose)
        {
            return;
        }
        
        gameAccount.Dispose();
    }

    /// <summary>
    /// 从缓存中移除执行的账号实体。
    /// </summary>
    /// <param name="self"></param>
    /// <param name="gameAccount">账号实体</param>
    /// <param name="isDispose">移除后是否销毁实体对象，默认为true</param>
    public static void Remove(this GameAccountManageComponent self, GameAccount gameAccount, bool isDispose = true)
    {
        self.Accounts.Remove(gameAccount.Id);
        
        if (!isDispose)
        {
            return;
        }
        
        gameAccount.Dispose();
    }

    /// <summary>
    /// 数据库加载或创建一个游戏账号。
    /// 先检查缓存，缓存没有则从数据库加载，数据库没有就创建新账号。
    /// 最后确保账号已经加入到缓存中。
    /// </summary>
    /// <param name="self"></param>
    /// <param name="accountId">账号ID</param>
    /// <returns></returns>
    public static async FTask<GameAccount> LoadOrCreate(this GameAccountManageComponent self, long accountId)
    {
        //1.优先从缓存获取，避免重复加载或数据库的压力。
        if (self.Accounts.TryGetValue(accountId, out var gameAccount))
        {
            return gameAccount;
        }
        //2.尝试从数据库查询
        gameAccount = await self.Scene.World.Database.Query<GameAccount>(accountId, true);
        //3.数据库不存在则执行创建逻辑
        if (gameAccount == null)
        {
            gameAccount = Entity.Create<GameAccount>(self.Scene, accountId, false, false);
            // 新创建的账号，要执行一次插入数据库
            await self.Scene.World.Database.Insert(gameAccount);
        }
        //4.将账号加入到管理器的缓存中。
        self.Accounts.Add(gameAccount.Id, gameAccount);
        return gameAccount;
    }
}