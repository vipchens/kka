using Fantasy.Async;
using Fantasy.Network;

namespace Fantasy.Hotfix;

public static class GameAccountSystem
{
    /// <summary>
    /// 账号上线处理逻辑
    /// </summary>
    /// <param name="self"></param>
    public static async FTask Online(this GameAccount self)
    {
        await FTask.CompletedTask;
    }

    /// <summary>
    /// 账号下线处理逻辑
    /// </summary>
    /// <param name="self"></param>
    /// <param name="timeout">延迟下线的时间</param>
    public static async FTask Offline(this GameAccount self,int timeout)
    {
        var accountId = self.Id;
        var gameAccountManageComponent = self.Scene.GetComponent<GameAccountManageComponent>();

        if (!gameAccountManageComponent.TryGet(accountId, out var gameAccount))
        {
            // 如果缓存中没有，那表示已经下线或者根本不存在该账号，所以应该打印一个警告，因为这个情况基本是不会出现了。
            Log.Warning($"GameAccountSystem Offline accountId : {accountId} not found");
            return;
        }

        if (!self.Scene.TryGetEntity<Session>(self.SessionRuntimeId, out var session))
        {
            // 为了防止逻辑的错误，也加一个警告来排查下。
            // 如果没有找到对应的Session，那只有一种可能，就是当前的连接会话已经断开了，一般情况下是不可能出现的。
            Log.Warning($"GameAccountSystem Offline accountId : {accountId} SessionRuntimeId : {self.SessionRuntimeId} not found");
            return;
        }

        if (timeout <= 0)
        {
            // 直接执行下线操作
            await self.OfflineByInner();
        }
        
        // 设置延迟下线
        gameAccount.SetDestroyTimeout(timeout,self.OfflineByInner);
    }
    
    private static async FTask OfflineByInner(this GameAccount self)
    {
        // 保存自己到数据库中。
        await self.Scene.World.Database.Save(self);
        // 再缓存中移除自己，并且执行自己的Dispose方法
        self.Scene.GetComponent<GameAccountManageComponent>().Remove(self);
    }
}