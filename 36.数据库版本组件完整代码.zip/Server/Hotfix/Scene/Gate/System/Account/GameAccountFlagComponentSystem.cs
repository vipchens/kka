using Fantasy.Entitas.Interface;
// ReSharper disable ConditionIsAlwaysTrueOrFalseAccordingToNullableAPIContract
#pragma warning disable CS8625 // Cannot convert null literal to non-nullable reference type.

namespace Fantasy.Hotfix;

public sealed class GameAccountFlagComponentDestroySystem : DestroySystem<GameAccountFlagComponent>
{
    protected override void Destroy(GameAccountFlagComponent self)
    {
       GameAccount account= self.GameAccount;

       if (account == null)
       {
           return;
       }
       
       // 执行下线流程
       account.Offline(5000).Coroutine();
       self.GameAccount = null;
    }
}

public static class GameAccountFlagComponentSystem
{
    public static void SetAccount(this GameAccountFlagComponent self, GameAccount gameAccount)
    {
        self.GameAccount = gameAccount;
    }
}